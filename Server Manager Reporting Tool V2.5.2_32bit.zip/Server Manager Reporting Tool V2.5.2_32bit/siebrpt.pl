#
$version="Version 2.5.2 - Last Updated January 23, 2015";
#----------------------------------------------------------------------------------------------------
# siebrpt.pl - Perl Script
#
# Program to get Siebel Enterprise Information
# from server manager command line calls
# including all installed Siebel Server Components
# and their parameters.
#
# Written by:  Ely Kahwaty
# Property of: Siebel Systems, Inc.
# Created: October 29, 2003
# Last Updated: January 23, 2015 by Frank Lin
#
# To execute:
#
# 1. Set your siebel environment.  Run siebenv.sh or equivalent.
#
# 2. perl siebrpt.pl <gateway> <enterprise> <username> <password> <logfile>
#
#-----------------------------------------------------------------------------------------------------
my ($gateway, $enterprise, $user, $password, $outfile) = @ARGV;	# Get command line options.
#
$outfile = "$outfile.html";
$outfile_cmd = "$outfile.commands";
$delimiter = ":::";
$reportingdate = localtime(time);
@command_explained=("This is the explanation of what the command reports and what you might do to analyze output.\n",
                      "Use this to help understand the output and the command itself.\n");
check_command(); #subroutine to do a generic check on the right syntax
check_env(); # subroutine to check siebel environment
$cmd = "$srvrmgr_exe /g $gateway /e $enterprise /k $delimiter /u $user /p $password ";
$cmd_nopass = "$srvrmgr_exe /g $gateway /e $enterprise /k $delimiter /u $user /p ****** ";
open_logfile(); # subroutine to open the file to produce the report
@report_header=("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Frameset//EN\" \"http://www.w3.org/TR/html4/frameset.dtd\"\n>",
              "<HTML>\n",
              "<HEAD>\n",
              "<TITLE>\n",
              "Server Manager Component Parameter Report - Oracle Expert Services - $reportingdate\n",
              "</TITLE>\n",
              "<STYLE type=\"text/css\">\n",
              "H1    {align: left; color: Black; font-family: Verdana; font-size: 13pt; background-color: Aqua}\n",
              "H2    {align: left; color: Blue;   font-family: Verdana;   font-size: 12pt; font-weight: bold; text-decoration: underline;}\n",
              "H3    {align: left; color: Red;    font-family: Verdana;  font-size: 10pt; font-weight: extra-bold}\n",
			  "H4    {align: left; color: White;    font-family: Garamond;  font-size: 24pt; background-color: Red}\n",
              "BODY  {font-family: Verdana; font-size: 8pt}\n",
              "</STYLE>\n",
              "</HEAD>\n",
              "</HTML>\n",
              "<H4 id=\"TopOfPage\">\n",           
              "ORACLE - Siebel Application Server Manager Report\n",
	          "</H4><br>\n",
              "<H3 id=\"TopOfPage\">\n",           
              "Siebel Enterprise: $enterprise - Execution of: $version<br>\n",
	          "Command Line: $cmd_nopass <br>\n", 
              "</H3><br>\n",
              "Copyright <A href=\"http://www.oracle.com\">ORACLE Corporation - Oracle Expert Services, 2003-2013 - All rights reserved.</A><br><br>\n",
              "\nNOTE: Useful srvmgr command file output is located at the bottom of this report.<br>\n",
              "\nNOTE: Commands used to capture this output were saved to a file. Look for $outfile.commands in the current directory.<br><br>\n");
print "Attempting report generation...\n";
get_servers(); # subroutine to get Siebel Servers in the enterprise
#get_comp_status(); # subroutine to get the status of all components in the enterprise
get_ent_params(); # subroutine to get Siebel Enterprise Parameters
get_component_parms(); # subroutine to get all components for all servers and list parameters
#get_tasks(); #subroutine to list tasks
get_subsystem_parms(); # sub to get named subsystems and params
run_om_analysis();
run_latch_analysis();
push(@report_temp,"\n<P><P> <H2>Components which have no tasks run on a server:</H2><P>\n\n",@notaskslist, "\n");
push(@report_temp,@shutdown_all_comps);							  
write_to_report(); # send the current array of output to the output file
print "\nReport HTML output and command history output can be located in the current directory.\nLook for files named $outfile and $outfile_cmd\n";
#
#
# Begin Subroutines
# **************************************************************************************************
sub run_latch_analysis {
# Go through all records
@report_temp=(@report_temp,"\n","<br><P><P> <H2>Server Latch Setting Environment Variable Analysis Report</H2><P><br>\n");
foreach $key (keys (%servertaskcounts)) { # once for each key of %servertaskcounts hash
    $siebel_osd_nlatch = ($servertaskcounts{$key} * 7 + 1000);
	$siebel_osd_latch = ($servertaskcounts{$key} * 2);
    @report_temp=(@report_temp,"\nSiebel Server $key has total tasks of $servertaskcounts{$key}<br>\n",
	"Recommended setting for SIEBEL_OSD_LATCH for server $key is $siebel_osd_latch.<br>\n",
	"Recommended setting for SIEBEL_OSD_NLATCH for server $key is $siebel_osd_nlatch.<br>\n",
	"export SIEBEL_OSD_LATCH=$siebel_osd_latch; export SIEBEL_OSD_NLATCH=$siebel_osd_nlatch;<br>\n");
} # end for each

} # end sub
# **************************************************************************************************
sub run_om_analysis {
# Go through all records
@report_om=("\n","<br><P><P> <H2>Object Manager Summary</H2><P><br>\n");
@om_table=("<tr><th scope=\"col\">SERVER<\/th><th scope=\"col\">COMPONENT<\/th><th scope=\"col\">TASKS<\/th><th scope=\"col\">MINMT<\/th><th scope=\"col\">",
        "MAXMT<\/th><th scope=\"col\">PER SISN CONN<\/th><th scope=\"col\">MINDBCONNS<\/th><th scope=\"col\">MAXDBCONNS",
    	"<\/th><th scope=\"col\">TRXDBCONNS<\/th><th scope=\"col\">MSG BAR UPDATE INTRVL</tr></th>\n");
while (($name, $record) = each %byname) {
   push(@om_table, "<tr><td>$record->{SERVER}<\/td><td>$record->{COMP}<\/td><td>$record->{MAXTASKS}<\/td><td>$record->{MINMTSERVERS}<\/td><td>",
                   "$record->{MAXMTSERVERS}<\/td><td>$record->{SESSPERSISNCONN}<\/td><td>$record->{MINSHAREDDBCONNS}",
				   "<\/td><td>$record->{MAXSHAREDDBCONNS}<\/td><td>$record->{MINTRXDBCONNS}<\/td><td>$record->{MSGBARUPDATEINTERVAL}<\/td></tr>");
} # end while
@report_om = (@report_om,"<table border='1' width='90%' align='center' summary='Script output'>\n",@om_table,"\n</table><br>");
while (($name, $record) = each %byname) {
    @report_om=(@report_om,
	"\n<P><P> <H3>Component $record->{COMP} on server $record->{SERVER} alerts:</H3><P>");
	if ($record->{MAXTASKS}/$record->{SESSPERSISNCONN} != int $record->{MAXTASKS}/$record->{SESSPERSISNCONN}) {
	  @report_om=(@report_om,"ALERT: MaxTasks is not evenly divisible by Sessions Per SISNAPI Connection!<br>\n");
	  if ($record->{MAXTASKS}/5 == int $record->{MAXTASKS}/5) {
		@report_om=(@report_om,"Consider executing: \"change param sesspersisnconn=5 for server $record->{SERVER} compdef $record->{COMP}\"<br>\n");
	  } # end if
	} # end if
	if ($record->{MAXTASKS} == 20) {
	  @report_om=(@report_om,"ALERT: MaxTasks appears to have the out of box configuration!<br>\n");
	  @report_om=(@report_om,"Consider executing: \"change param maxtasks=100 for server $record->{SERVER} comp $record->{COMP}\"<br>\n");
	} # end if
	if ($record->{MAXSHAREDDBCONNS} == -1) {
	  if ($record->{MINSHAREDDBCONNS} == -1) {
	    if ($record->{MINTRXDBCONNS} == -1) {    # if all are -1 db connection pooling is disabled
		  @report_om=(@report_om,"ALERT: Database Connection Pooling appears to be disabled for this component!<br>\n");
		} # end if
	  } # end if
	} # end if
	if ($record->{MSGBARUPDATEINTERVAL} == 120) {
	  if ($record->{SHOWMESSAGEBAR} =~ "User") {
	    @report_om=(@report_om,"\tALERT: Message Broadcasting appears to have the out of box configuration! Sessions may not timeout",
		            " as Show Message Bar is set to $record->{SHOWMESSAGEBAR}.<br>\n");
	  } # end if
	} # end if
} # end while
} # end sub
# **************************************************************************************************
sub check_command {
if (@ARGV<5) {
   give_usage();
   print "Failure to supply the correct number of command line arguments.  Try again.\n\n\n";
   die "Argument Error...";
}																	
if (@ARGV>5) {
   give_usage();
   print "You have supplied too many command line arguments!!!  Try again.\n\n\n";
   die "Excessive Argument Error...";
}
} # end sub
# **************************************************************************************************	
sub check_env {
if ($ENV{'SIEBEL_HOME'}) {
  if ($ENV{'SIEBEL_HOME'} =~ /\w:/)
    { $srvrmgr_exe = "$ENV{'SIEBEL_HOME'}\\bin\\srvrmgr"; } # this is windows D:\sea752\siebsrvr
	else { $srvrmgr_exe = "$ENV{'SIEBEL_HOME'}/bin/srvrmgr"; } 	# else this is UNIX and is /sea752/siebsrvr
} else {
       print "SIEBEL_HOME not set???\n";
	   die "Please execute siebenv.bat or siebenv.sh!!\n";
}
} # end sub
# **************************************************************************************************
sub give_usage {
   print "\n*****$version******\n\nUsage:\n\n $0 <gateway> <enterprise> <user> <password> <logfile>\n\n\n";
   print "Example:\n\n $0 siebgtwy siebel SADMIN SADMIN SiebelReport\n\n\n";
}
# **************************************************************************************************
sub open_logfile {
# Open a file to create the output report.
$logfile=">$outfile";
open (LOGFILE, $logfile)
   or die "Couldn't open $outfile for writing: $!\n";
$logfile2=">$outfile_cmd";
open (LOGFILE2, $logfile2)
   or die "Couldn't open $outfile_cmd for writing: $!\n";
}
# **************************************************************************************************
sub clean_bottomlines {
	 $x=0;
	 until (pop(@outlines)=~/\d{1}\s(row|rows)\sreturned/) {
	 $x++;
	 }
	 extra_clean(); 
} # end sub
# **************************************************************************************************
sub check_cmd_output {	# This checks for output that is unexpected to modify the handling of array data
my($found, $item);
  foreach $item (@outlines) {
      if ($item =~ m/successfully/) { # Command completed sucessfully. - means no output...
          $found = 1;
          last;
      }
      if ($item =~ m/not\sa\svalid\slist/) { # not a valid list command - bad command
          $found = 1;
          last;
      }
      if ($item =~ m/unexpected\skeyword/) { # bad keyword
          $found = 1;
          last;
      }
      if ($item =~ m/There\sis\sno\sconnected\sserver\stargeted/) {	# Not connected to that server
          $found = 1;
          last;
      }	  	  
  }
  if ($found) {
	  clean_leading();
	  extra_clean(); extra_clean(); extra_clean();
  } else {
         clean_bottomlines();
         clean_leading(); # clean leading output of unwanted lines
  }
} # end sub
# **************************************************************************************************
sub extra_clean {
   pop(@outlines);
}
# **************************************************************************************************
sub clean_leading {
	rev_out();
	$y=0;
	until (pop(@outlines)=~/srvrmgr\>/) {
	$y++;
#	print "Popping Leading $y\n";
	}
	rev_out();
} # end sub
# **************************************************************************************************
# Reverses Array @outlines to allow for easily removing unwanted lines.
sub rev_out {
  @outlines = reverse(@outlines);
}
# **************************************************************************************************
# subroutine to call srvmgr with the correct command and capture output
# **************************************************************************************************
sub ext_cmd_control { # begin sub - accepts valid server manager command as input parameter

use IPC::Open3;
  $pid = open3(*HIS_IN, *HIS_OUT, *HIS_ERR, $cmd) || die $!;
  print HIS_IN $_[0];
  print HIS_IN "exit\n";
  close(HIS_IN)|| die "can't close: $!";  # give end of file to the input stream
  @outlines = <HIS_OUT>;              # read till EOF
  @errlines = <HIS_ERR>;              # XXX: block potential if massive
#  $COUNT_OUT = @outlines;
  $COUNT_ERR = @errlines;
  $srvrmgr_command=$_[0];
if ($COUNT_ERR==0) { # begin count_err if
   foreach (@outlines) { # begin foreach
     if (/Connected\sto\s\d{1}\sserver/) { # begin if connected
	   (undef,undef,$connect_count,undef,undef,undef,undef,undef,undef,$total_servers) = split (" ", $_);
	      if ($connect_count=~0) { # begin if connect_count
	        print "ERROR:\n", $_, "\n";
		    warn "You are not connected to any Siebel Servers!!!";
	      } # end if connect_count
	      unless ($connect_count eq $total_servers) { # begin unless
	        warn "You are only connected to $connect_count of $total_servers servers.\n";
	      } # end unless
    	} # end if connected 
#	print "About to compare $_ to regex SBL-ADM-...\n";
	if (/SBL\-ADM\-\d*/) { # begin if SBL-
      print "ERROR:\n", $_, "\n";
	  warn "Server manager Siebel error...";
	  } # end if SBL-
	if (/ADM\-\d*/) { # begin if ADM-
      print "ERROR:\n", $_, "\n";
	  warn "Server manager Admin error...";
	  } # end if ADM-  
   } # end foreach outlines
   print $_[0];
   print LOGFILE2 $_[0];
   check_cmd_output();
 } else { # else count_err if
        print "ERROR:\n", @errlines, "\n";
		write_to_report();
		die "Server Manager error...aborting";
	} # end else
  close(HIS_OUT)|| die "can't close: $!";
  close(HIS_ERR)|| die "can't close: $!";
  waitpid $pid, 0;
  return $_[0];
} # end sub
# **************************************************************************************************
sub write_to_report {
   print LOGFILE @report_header,@report_om,@report_temp;
} # end sub
# **************************************************************************************** **********
sub get_components {
@command_explained=("This lists all enterprise components.  Alias, name, and value are shown.\n");
cat_lines(ext_cmd_control("list components for server \"$siebsrvr\" show SV_NAME, CC_ALIAS, CG_ALIAS, CP_DISP_RUN_STATE, CP_STARTMODE, CP_NUM_RUN_TASKS, CP_MAX_TASKS, CP_ACTV_MTS_PROCS, CP_MAX_MTS_PROCS\n"));
} # end sub
# **************************************************************************************************
sub get_comp_status {
@command_explained=("This lists all enterprise components.  Alias, name, and runstate are shown.\n",
                    "Check for components that are unavailable, as this may indicate problems.\n");
cat_lines(ext_cmd_control("list components show SV_NAME, CC_ALIAS, CG_ALIAS, CP_DISP_RUN_STATE, CP_STARTMODE, CP_NUM_RUN_TASKS, CP_MAX_TASKS, CP_ACTV_MTS_PROCS, CP_MAX_MTS_PROCS\n"));
} # end sub
# **************************************************************************************************
sub get_component_parms {
  ext_cmd_control("list components show SV_NAME, CC_ALIAS, CP_DISP_RUN_STATE\n");
  # Reverse the output lines from get components and remove 2 more lines from the top
  rev_out();
  for ($c=1; $c <= 2; $c++) { extra_clean(); }
  rev_out();
  @complist=@outlines; # we need a new array while we work with each component
  push (@shutdown_all_comps,
  "\n<br><P><P> <H3>Component shutdown commands provided for unused components as starting place for shutting down unnecessary components.</H3><P>\n\n");
	%servertaskcounts = ();
	foreach (@complist) {  # Begin for each siebel server component in the list
	($siebsrvr, $component, $run_state) = split ($delimiter, $_);
	($siebsrvr) = split (" ", $siebsrvr);
	($component) = split (" ", $component);
	($run_state) = split (" ", $run_state);
	chomp $component;
# print "$siebsrvr, $component, $run_state\n";
  if ($run_state) {
	if (substr($component,0,8) ne 'SiebSrvr') { # if not component SiebSrvr which is a root component and will error
	  @command_explained=("This lists parameters specific to the component $component.  Alias and value are shown.  Look for\n",
	                    "things such as proper MaxTasks and thread to process ratios for multi-threaded components.\n");
 	  cat_lines(ext_cmd_control("list params for comp $component server \"$siebsrvr\" SHOW PA_ALIAS, PA_VALUE\n"));
	  check_om_ratio();

	  @command_explained=("This lists hidden parameters specific to the component $component.  Alias and value are shown.  Look for\n",
	                    "any deviation from best practices.\n");
      cat_lines(ext_cmd_control("list hidden params for comp $component server \"$siebsrvr\" SHOW PA_ALIAS, PA_VALUE\n"));
	  check_om_ratio();
	
 	  @command_explained=("This lists advanced parameters specific to the component $component.  Alias and value are shown.  Look for\n",
	                    "any deviation from best practices.\n");
      cat_lines(ext_cmd_control("list advanced params for comp $component server \"$siebsrvr\" SHOW PA_ALIAS, PA_VALUE\n"));
	  check_om_ratio();  # this procedure call loads key parameters into variables for further analysis
	
	  @command_explained=("This lists log levels specific to the component $component.  Alias and level are shown.  Look for\n",
	                    "log levels which have been unnecesarily increased in a production environment.  Default level is 1.\n",
						"and the maximum log level is 5.  Logging adds overhead and increases disk usage so should be used with care.\n");
      cat_lines(ext_cmd_control("list evtloglvl for comp $component server \"$siebsrvr\" SHOW ET_NAME, ET_ALIAS, EC_LOGHNDL_LVL\n"));

	  @command_explained=("This lists statistics specific to the component $component.  Alias and value are shown.  Look for\n",
	                    "things such as no tasks being run and if component parameter TimedStats has been set to true even more.\n");
      cat_lines(ext_cmd_control("list stats for server $siebsrvr comp $component SHOW STAT_ALIAS, CURR_VAL, SD_DESC\n"));
	  record_no_tasks();
    $servertaskcounts{$siebsrvr} += $maxtasks;
    if ($component =~ "ObjMgr") {	# only capture for Object Manager Components
      $servcomp = $siebsrvr . "_" . $component;
      if ($maxmtservers == 0) {
	    $record = {
	    NAME					=> $servcomp,
	    SERVER   				=> $siebsrvr,
	    COMP     				=> $component,
	    MAXTASKS  				=> $maxtasks,
        MINMTSERVERS  			=> $minmtservers,
        MAXMTSERVERS   			=> $maxmtservers,
        SESSPERSISNCONN			=> $sesspersisnconn,
        RATIO   				=> 0,
	    MAXSHAREDDBCONNS		=> $maxshareddbconns,
	    MINSHAREDDBCONNS		=> $minshareddbconns,
	    MINTRXDBCONNS			=> $mintrxdbconns,
	    MSGBARUPDATEINTERVAL	=> $msgbarupdateinterval,
	    SHOWMESSAGEBAR			=> $showmessagebar,
	    }; } else {	# end if start else
	       $record = {
	       NAME					    => $servcomp,
	       SERVER   				=> $siebsrvr,
	       COMP     				=> $component,
	       MAXTASKS  				=> $maxtasks,
           MINMTSERVERS  			=> $minmtservers,
           MAXMTSERVERS   			=> $maxmtservers,
           SESSPERSISNCONN			=> $sesspersisnconn,
           RATIO   				    => $maxtasks/$maxmtservers,
	       MAXSHAREDDBCONNS		    => $maxshareddbconns,
	       MINSHAREDDBCONNS		    => $minshareddbconns,
	       MINTRXDBCONNS			=> $mintrxdbconns,
	       MSGBARUPDATEINTERVAL	    => $msgbarupdateinterval,
	       SHOWMESSAGEBAR			=> $showmessagebar,
	       }; } # end else
      # store record
      $byname{ ($record->{NAME}) } = $record;
    } # end if object manager component
  } # end if not SiebSrvr component
  } # end for each siebel server component in the list
 } # End if server not running
} #end sub
# **************************************************************************************************
sub get_servers {
@command_explained=("This is a listing of all Siebel Servers in the enterprise.  Look to see that they are all\n",
                    "running and in a sound state.  If servers are not running or in an abnormal state look for errors\n",
					"in the server log for that Siebel Server.\n");
cat_lines(ext_cmd_control("list servers SHOW SBLSRVR_NAME, HOST_NAME, INSTALL_DIR, SBLSRVR_STATE, SBLSRVR_STATUS\n"));
rev_out();
for ($c=1; $c <= 2; $c++) { extra_clean(); }
rev_out();
@servlines=@outlines;
foreach (@servlines) {
  ($siebsrvr, $hostsrvr, $installdir, $running, $version) = split (":::", $_);
# print "$siebsrvr,$hostsrvr,$installdir,$running,$version\n";
  ($siebsrvr) = split (" ", $siebsrvr);
  ($running) = split (" ", $running);
# print "$siebsrvr,$running,\n";
  if ($running) {
# @command_explained=("This is a listing of all component groups for server $siebsrvr. The name and alias are listed here.\n",
#                      "This is usefull for further referencing the component group later in the report by alias.\n");
# cat_lines(ext_cmd_control("list component groups for server $siebsrvr SHOW CG_NAME, CG_ALIAS\n"));
  @command_explained=("This is a listing of all component groups for server $siebsrvr. Look to see that they are all\n",
                      "running and in a sound state.  Note what has been shutdown.  If the component groups are part offline\n",
					  "this might indicate problems.\n");
  cat_lines(ext_cmd_control("list component groups for server $siebsrvr SHOW CG_NAME, CG_ALIAS, CG_DISP_ENABLE_ST, CA_RUN_STATE\n"));
  @command_explained=("This lists all enterprise components.  Alias, name, and value are shown.\n");
  cat_lines(ext_cmd_control("list components for server \"$siebsrvr\" show SV_NAME, CC_ALIAS, CG_ALIAS, CP_DISP_RUN_STATE, CP_STARTMODE, CP_NUM_RUN_TASKS, CP_MAX_TASKS, CP_ACTV_MTS_PROCS, CP_MAX_MTS_PROCS\n"));
# @command_explained=("This is a listing of all named subsystems for server $siebsrvr.\n");
# cat_lines(ext_cmd_control("list named subsystems for server \"$siebsrvr\" SHOW NSS_ALIAS, SS_ALIAS\n"));
# @command_explained=("This lists sessions for the server $siebsrvr.  The state, login, and last view are shown.\n",
#                     "This is usefull for identifying usage of the application.  Look for situations where the same\n",
#					  "login appears repeatedly.  This could indicate abandoned sessions and timeout setting issues.\n");
# cat_lines(ext_cmd_control("list sessions for server \"$siebsrvr\" SHOW TK_DISP_RUNSTATE, OM_LOGIN, OM_VIEW\n"));
  @command_explained=("This lists sessions for the server $siebsrvr.  The task, process, runstate, and hungstat are shown.\n",
                      "This is usefull for identifying hung sessions and tracking back the session to the operating system.\n",
					  "The TK_PID identifys the process number that the task is running on for that server's OS. Tasks which\n",
					  "share the same TK_PID are running as threads in the same process.\n");
  cat_lines(ext_cmd_control("list sessions for server \"$siebsrvr\" SHOW CC_ALIAS, TK_TASKID, TK_PID, TK_DISP_RUNSTATE, TK_HUNG_STATE, OM_LOGIN, OM_VIEW\n"));
  @command_explained=("This lists all tasks for all servers including those that have been completed.  Look for indication of errors.\n");
  cat_lines(ext_cmd_control("list tasks for server \"$siebsrvr\" SHOW SV_NAME, CC_ALIAS, TK_STATUS, TK_TASKID, TK_PID\n")); # append lines for the report
} # end if server is not running
} # end for loop
} # end sub
# **************************************************************************************************
sub get_tasks {
@command_explained=("This lists all tasks for all servers including those that have been completed.  Look for indication of errors.\n");
cat_lines(ext_cmd_control("list tasks SHOW SV_NAME, CC_ALIAS, TK_STATUS, TK_TASKID, TK_PID\n")); # append lines for the report
} # end sub
# **************************************************************************************************
sub get_ent_params {
@command_explained=("This lists all Enterprise Wide Parameters.  Check that AutoRestart has been set to True.\n");
cat_lines (ext_cmd_control("list ent params SHOW PA_ALIAS, PA_VALUE\n")); 
#push(@entparmlist, "PA_ALIAS = PA_VALUE (NULL Indicates no assigned value for parameter)\n",
#"--------------------------------------------------------------------\n");
#rev_out();
#for ($c=1; $c <= 2; $c++) { extra_clean(); }
#rev_out();
#foreach (@outlines) {
#  ($alias, $value, undef) = split ($delimiter, $_);
#  unless ($value) { $value="NULL"; }
#  push(@entparmlist,"$alias = $value\n");
#} # end foreach
#@report_temp=(@report_temp,"\n","$srvrmgr_command\n");
#  push(@report_temp,@entparmlist);
} # end sub
# **************************************************************************************************
sub cat_lines {	# accepts server manager command as parameter and formats all output in HTML
  @report_temp=(@report_temp,"<br><br>\n","<P><P> <H2>$_[0]</H2><P>\n","<P><P> <H3>@command_explained</H3><P>\n");
  @printlines = @outlines;
  chomp(@printlines);
  foreach (@printlines) { # add some breaks to fill out empty strings in the tables
	$_ =~ s/$delimiter\s+$delimiter\s+$delimiter/$delimiter<br>$delimiter<br>$delimiter/g;
	$_ =~ s/$delimiter\s+$delimiter/$delimiter<br>$delimiter/g;
  } # end foreach
  for ($i = 0; $i <= 3; $i++) { chop(@printlines); };
  delete $printlines[1];
	$index = 0;
	foreach (@printlines) {	# format the first line of the HTML table in bold and the remaining lines in plain text
	  if ($index == 0) {
	    $_ =~ s/$delimiter/<\/th><th scope=\"col\">/g; 
        $_ = "<tr><th scope=\"col\">$_</tr></th>\n";
	   }  else {
	      $_ =~ s/$delimiter/<\/td><td>/g; 
	  if ($index != 1) { # Fix Table Format issue
          $_ = "<tr><td>$_</td></tr>\n";
                           }
		  } # end if then else
	  $index++;
	} # end foreach
  @printlines = ("<table border='1' width='90%' align='center' summary='Script output'>\n",@printlines,"\n</table><br>");	
  push(@report_temp,@printlines);
  @command_explained=("No descriptive text has been supplied for this command.\n");
}
# **************************************************************************************************
sub record_no_tasks {
foreach (@outlines) {
  ($parameter, $value) = split ($delimiter, $_);
  	if ($parameter=~'TotalTasks' and $value==0) {
	  push(@notaskslist,"Siebel Server component $component has zero total tasks on server $siebsrvr.<br>\n");
	  push (@shutdown_all_comps, "shutdown component $component for server $siebsrvr<br>\n");
      } # end if
} # end foreach
} # end sub
# **************************************************************************************************
sub check_om_ratio {
foreach (@outlines) {
  ($parameter, $value) = split ($delimiter, $_);
    if ($parameter =~ 'MaxTasks') {
	  $maxtasks=$value;
      } # end if
  	if ($parameter =~ 'MinMTServers') {
	  $minmtservers=$value;
      } # end if	  
  	if ($parameter =~ 'MaxMTServers') {
	  $maxmtservers=$value;
      } # end if	  
  	if ($parameter =~ 'SessPerSisnConn') {
	  $sesspersisnconn=$value;
      } # end if
  	if ($parameter =~ 'MaxSharedDbConns') {
	  $maxshareddbconns=$value;
      } # end if
  	if ($parameter =~ 'MinSharedDbConns') {
	  $minshareddbconns=$value;
      } # end if	  
  	if ($parameter =~ 'MinTrxDbConns') {
	  $mintrxdbconns=$value;
      } # end if
	if ($parameter =~ 'MsgBarUpdateInterval') {
	  $msgbarupdateinterval=$value;
      } # end if	  
  	if ($parameter =~ 'ShowMessageBar') {
	  $showmessagebar=$value;
      } # end if	  	  

} # end foreach
} # end sub
# **************************************************************************************************
sub list_named_subsystem {
@command_explained=("The named subsystems for the enterprise.\n");
cat_lines(ext_cmd_control("list named subsystems show SS_ALIAS, NSS_ALIAS\n"));
} # end sub
# **************************************************************************************************
sub get_subsystem_parms {
  list_named_subsystem();
  # Reverse the output lines from get components and remove 2 more lines from the top
  rev_out();
  for ($c=1; $c <= 2; $c++) { extra_clean(); }
  rev_out();
  @sublist=@outlines; # we need a new array while we work with each component
    foreach (@sublist) {
    ($subsystem, $named_sub) = split ($delimiter, $_);
	@command_explained=("This lists parameters specific to the named subsystem $named_sub in subsystem $subsystem.\n");
	cat_lines(ext_cmd_control("list params for named subsystem $named_sub SHOW PA_ALIAS, PA_VALUE\n"));
	cat_lines(ext_cmd_control("list advanced params for named subsystem $named_sub SHOW PA_ALIAS, PA_VALUE\n"));
	cat_lines(ext_cmd_control("list hidden params for named subsystem $named_sub SHOW PA_ALIAS, PA_VALUE\n"));
  } # end foreach
} #end sub
# **************************************************************************************************