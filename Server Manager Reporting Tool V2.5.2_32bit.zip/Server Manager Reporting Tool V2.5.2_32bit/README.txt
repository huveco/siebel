Version 2.5.2 - Last Updated January 23, 2015
----------------------------------------------------------------------------------------------------
 siebrpt.pl - the perl script for generating a server manager report as described below
 siebrpt.exe - Executable Created from a Perl Program using perl2exe

 Program to report Siebel Enterprise Information
 including all installed Siebel Server Components
 and their parameters.

 This is an full release version.

 Written by:  Ely Kahwaty
 Property of: Oracle Corporation
 Created: October 29, 2003 for Siebel System, Inc.


 To execute:

 1. Set your siebel environment.  Run siebenv.sh or equivalent.

 2. siebrpt.exe <gateway> <enterprise> <username> <password> <logfile>

 Example: siebrpt.exe GTWY-SRVR siebel SADMIN SADMIN report.log

 	For UNIX use the perls script and assuming perl is installed on the system:

 	perl siebrpt.pl <gateway> <enterprise> <username> <password> <logfile>

 For Windows 2008 environments:
      An error can occur such as: �siebrpt.exe is not valid win32 application�

      Solution: 
	Use Windows 2003 compatability mode:  Open windows explorer, locate the folder where file is located. i.e. d:\sba81\siebsrvr\bin, right click on the file name -> �Properties -> Compatibility -> Windows 2003 SP2 �-> Check Run as Administrator and apply the changes.

 NOTES:

 I have only tested this program against:

 version 7.5.3 of Siebel on Windows
 version 7.5.2 of Siebel on Sun Solaris with perl, version 5.005_03 built for sun4-solaris
 version 7.7 of Siebel on Windows
 version 7.8 of Siebel on Windows
 version 7.8 of Siebel on Solaris 9
 version 8.0 of Siebel on Windows
 version 8.1 of Siebel on Windows/Linux/AIX
 version 8.2 of Siebel on Windows

Bug Alert:  Version 2.3.0 was found to error on perl 5.005_03, please use txt version 2.2.1 in this case, no fix is available

 ** IF YOU ENCOUNTER srvrmgr ERRORS ON UNIX - Possibly change the command line in the script on line 28 to use
 a "-" instead of a "\".  I have not encountered this, but it may be an issue on some UNIX
 systems.

 I have tried to implement error handing in this program.  Many cases of bad
 command line arguments are handled.  Some may not be.  The worst case should
 be that you have to kill the program with a CTRL-C or CTRL-Z.

 If you have a problem and the report file gets locked.  Look to kill an errant srvrmgr
 process from the operating system.

 Ideas are appreciated.  I am looking for additional server manager commands that might be
 usefull in a PHC or PRR situations.

 September 2005 - The tool has been modified to hopefully handle error situations more
   gracefully.  It is less likely to abort when a command is rejected.  This could make
   it more prone to hangs, so be sure to monitor it during use.

 October 2005 - Look for the new sections on Object Manager Analysis and Latch Analysis near the end of the report.

 March 2006 V2.2.6 - Added command file which formats a server manager script.  This provides a way of quickly re-generating
   the detail output that the original report was generated from.  The generated script can be called from server manager
   with the read <logfile.log.commands> syntax. Also, the program has been changed to not abort even if any or all Siebel
   Servers are down. 

 February 2007 - Changed output to HTML and altered order of information
 
 June 30, 2011; Scott Saunders documentation update: Windows 2008 environment instructions

 September 30, 2012 V2.4.3 - Updated by Frank Lin to skip Siebel App Servers with status down; enhancement table format/icons. (Note: only tested on AIX, Linux(SUSE/RedHat), Windows)

 August 01, 2013 V2.5.0 - Updated by Frank Lin to add support for getting hidden and advanced parameters for ServerDataSrc sub-system.
 
 December 23, 2013 V2.5.1 - Updated by Frank Lin to switch back to 32 bit for better compatibility.

 January 23, 2015 V2.5.2 - Updated by Frank Lin to revise banner version string and comments.

Send ideas to ely.kahwaty@oracle.com


-----------------------------------------------------------------------------------------------------
