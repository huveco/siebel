This is a readme file for the "solaris_profile_v10.sh" script 
(henceforth referred to as script), version 10.

The script has been created by Oracle Advanced Customer Support Services 
to collect information about hardware, software and kernel settings 
on Solaris servers.

The script will ask for the following information from you -
1. Name of the customer or project; you may enter anything that
is meaningful to you.

To run on Solaris, copy the script to a temporary directory, 
which should preferably be empty and run the shell script
e.g. as "sh solaris_profile_v10.sh" or chmod +x the file and 
just enter the name of the file.  



