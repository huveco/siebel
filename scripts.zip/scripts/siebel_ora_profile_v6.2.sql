--  ******** Copyright ORACLE ACS 2003-2014  ***************

-- ==============================================================================
-- LAST UPDATED BY Z TANG
-- ==============================================================================
-- ==============================================================================
-- This Oracle profile script is used to collect database profile information for Siebel CRM applications.
--
-- It needs to be run as a user who has read privileges on the V$ virtual tables and the DBA_ tables.
-- To get all hidden database parameters, "SYS" privilege is needed
-- The script will prompt for the Siebel Schema name and the customer name.
-- 
-- Note that when providing the customers's name, DO NOT USE single/double quotes.
-- Please use alphanumeric (0-9, A-Z, a-z), hyphen and punctuation characters only.
--
-- The output report will be named "{db_name}_Siebel_ora_profile_{timestamp}.html" in your current directory.
-- It can be opened in any browser.
-- 
-- Whenever you update this script, please document the update history with the following information
-- Date, Version, Change Author and the text/description of the text.
-- ==============================================================================
-- Update History
-- ==============================================================================
-- May 21, 2003 : Version 1.0 : Jayesh Thakrar
-- Script made available for general Expert Services use
-- Sep 10, 2003 : Version 2.0 : Sundar Vikirapandiyam
-- Sep 29, 2003 : Version 3.0 : Sundar Vikirapandiyam - Removed info from Party queries.
-- Jan 06, 2005 : added query for hidden parameters, removed info about pga_aggregate_target
-- Oct 27, 2005 : Version 4.1 : fixed syntax error in Tablespace Profile Query : Ely Kahwaty
-- Mar 09, 2005 : Version 4.3 : added cache advisory queries for Buffer, Shared Pool, PGA : Ely Kahwaty
-- Jul 20, 2006 : Version 4.6 : added system stats check; added stats queries and other advisories; table row counts
-- Feb 12, 2007 : Version 5.0 : added table counts, buffer contention, changed font to Verdana; Ely Kahwaty
-- May 13, 2011 : Version 5.0 : Uncommented query on v$parameters, so "SYS" privilege is not required.
-- Nov 11, 2014 : Version 6.0 : Make the script RAC aware and some other changes.
-- Dec 17, 2014 : version 6.1 : Some format change; comments out Audit Trail detail due to performance issue with large set of audit item.
-- ==============================================================================

DEFINE SCRIPT_VERSION="v6.2"

SET LINESIZE 175 ;
SET PAGESIZE 5000 ;

COLUMN OUTPUT_FILE new_val OUTPUT_FILE

ACCEPT TABLE_OWNER   PROMPT 'Enter Siebel Table/Schema Owner Name: '
ACCEPT CUSTOMER_NAME PROMPT 'Enter Customer Name: '

SELECT 	NAME||'_Siebel_ora_Profile_'||to_char(sysdate, 'MON-DD-YYYY_HH24MI' )||'.html' OUTPUT_FILE 
FROM 	v$database;

SPOOL &OUTPUT_FILE

SET HEADING  OFF
SET FEEDBACK OFF
SET VERIFY   OFF

PROMPT <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd"> 
PROMPT <HTML>
PROMPT <HEAD>

PROMPT <TITLE>
SELECT 'Oracle Profile Script Report (Version &&SCRIPT_VERSION) for ' || '&&CUSTOMER_NAME'  ||  ' run on '  ||  TO_CHAR(SYSDATE, 'MON-DD-YYYY HH24:MM:SS PM') FROM DUAL ;
PROMPT </TITLE>

PROMPT <STYLE type="text/css">
PROMPT  H1    {align: left; color: Black; font-family: Times; font-size: 16pt; background-color: Aqua} 
PROMPT  H2    {align: left; color: Blue;   font-family: Arial;   font-size: 12pt; font-weight: bold; text-decoration: underline;} 
PROMPT  h2    {align: left; color: Blue;    font-family: Arial;  font-size: 12pt; font-weight: extra-bold} 
PROMPT  h3    {align: left; color: Black;    font-family: Arial;  font-size: 10pt; font-weight: bold} 
PROMPT  BODY  {font-family: Arial; font-size: 8pt} 

PROMPT </STYLE>
PROMPT </HEAD>
PROMPT <BODY>

PROMPT <H1 id="TopOfPage">
PROMPT Oracle Profile Report &SCRIPT_VERSION </H1>
PROMPT Copyright <A href="http://www.oracle.com">Oracle Advanced Customer Suppport</A>

PROMPT <br><br>
SELECT 'Oracle Profile Script Report (Version &&SCRIPT_VERSION) for <B><I><U>  ' || '&&CUSTOMER_NAME'  ||  '</U></I></B> run on '  || TO_CHAR(SYSDATE, 'MON-DD-YYYY HH24:MM:SS PM') FROM DUAL ;

PROMPT <OL>
PROMPT <LI> <A href="#Section1">  Basic Database and Instance Information      </A>
PROMPT <LI> <A href="#Section2">  Tablespace Information                       </A> 
PROMPT <LI> <A href="#Section3">  Redo and UNDO Information                    </A> 
PROMPT <LI> <A href="#Section4">  Schema Information                           </A> 
PROMPT <LI> <A href="#Section5">  Optimizer Statistics Information             </A> 
PROMPT <LI> <A href="#Section6">  Basic Database Performance Information       </A> 
PROMPT <LI> <A href="#Section7">  Advisory Information       			</A> 
PROMPT <LI> <A href="#Section8">  SQL Performance Information                	</A> 
PROMPT <LI> <A href="#Section9">  Oracle Session Information                    </A> 
PROMPT <LI> <A href="#Section10">  User Information                 	       </A> 
PROMPT <LI> <A href="#Section11">  Siebel Application Information               </A> 
PROMPT <LI> <A href="#Section12">  Siebel Remote Information                    </A> 
PROMPT <LI> <A href="#Section13">  Additional Information                	</A> 
PROMPT </OL>

SET MARKUP HTML ON ENTMAP OFF ;

SET HEADING  ON
SET FEEDBACK OFF
CLEAR BREAKS;
CLEAR COLUMNS;

PROMPT <h2 id="Section1">Basic Database and Instance Information</h2>


PROMPT
PROMPT <P><P><h3>Global Name </h3>

COLUMN GLOBAL_NAME FORMAT A100

SELECT GLOBAL_NAME 
FROM   GLOBAL_NAME ;

PROMPT
PROMPT <P><P><h3>Database Create Timestamp and Logging </h3>
COLUMN "DB CREATE TIMESTAMP" FORMAT A30

SELECT DBID DATABASE_ID, 
       NAME "DATABASE NAME", 
       TO_CHAR(CREATED, 'MON-DD-YYYY HH24:MM') "DB CREATE TIMESTAMP", 
       CHECKPOINT_CHANGE#,
       LOG_MODE, 
       (CASE WHEN log_mode = 'NOARCHIVELOG' THEN 'REDFLAG - Archive Logging Not Setup' END) "Error"
FROM   V$DATABASE ;

PROMPT
PROMPT <P><P><h3>Current Instance</h3>

SELECT HOST_NAME "HOST NAME",
       VERSION,
       TO_CHAR(STARTUP_TIME, 'MON-DD-YYYY HH24:MM') "INSTANCE START TIME", 
       STATUS,
       DATABASE_STATUS "DATABASE STATUS"
FROM   V$INSTANCE;

PROMPT
PROMPT <P><P><h3>All Database Instance Information</h3>

SELECT INSTANCE_NAME "INSTANCE NAME",
       INST_ID,
       HOST_NAME "HOST NAME",
       VERSION,
       TO_CHAR(STARTUP_TIME, 'MON-DD-YYYY HH24:MM') "INSTANCE START TIME", 
       STATUS,
       DATABASE_STATUS "DATABASE STATUS"
FROM   GV$INSTANCE 
ORDER BY INSTANCE_NAME;


PROMPT
PROMPT <P><P> <h3>Oracle Software Version Information </h3><P>
BREAK ON BANNER
BREAK ON "ORACLE SOFTWARE VERSION"

SELECT BANNER "ORACLE SOFTWARE VERSION", INST_ID
FROM   GV$VERSION 
ORDER BY 1,2;

PROMPT
PROMPT <P><P> <h3>Oracle Patch Information </h3><P>

select * from dba_registry_history
/

PROMPT
PROMPT <P><P><h3>Database NLS Parameters</h3>
Break on Parameter

SELECT PARAMETER, INST_ID, VALUE
FROM   GV$NLS_PARAMETERS 
ORDER BY 1,2;


PROMPT
PROMPT <P><P><h3>Oracle Initialization Parameters - From current instance</H2>
COL PARAMETER FOR A50
COL VALUE FOR A30
COL ISDEFAULT FOR A10 HEADING "DEFAULT?"
COL ISSES_MODIFIABLE FOR A12 HEADING "SESSION|MODIFIABLE?"
COL ISSYS_MODIFIABLE FOR A12 HEADING "SYSTEM|MODIFIABLE?"

SELECT NAME,
	VALUE,
       ISDEFAULT,
       ISSES_MODIFIABLE SES_MOD,
       ISSYS_MODIFIABLE SYS_MOD
FROM   V$PARAMETER
WHERE ISDEPRECATED='FALSE'
and     VALUE IS NOT NULL  
ORDER  BY NAME;

PROMPT
PROMPT <P><P><h3>SPFILE specified parameters - on all instances</H2>
PROMPT The following information could be used to identify discrepancies between init.ora parameters among RAC nodes.
PROMPT Some descrepancies are adequate. It could also be used to find if the parameter is specified (non-default). 
PROMPT The specified value could be the same as the default value in some case.
break on name

select 	name, 
	inst_id,
	value, 
	isspecified 
from gv$spparameter
where value is not null
order by 1,2
/

PROMPT
PROMPT <P><P><h3>Hidden Oracle Parameters</h3><P>
PROMPT- Comments: See section of "Additional Information"
clear breaks
 
PROMPT
PROMPT <P><P><h3>Oracle SGA Granule Size</h3>
COLUMN "GRANULE_SIZE (MB)" FORMAT 999,999,999,999

SELECT distinct inst_id, GRANULE_SIZE/1024/1024 "GRANULE_SIZE (MB)" 
FROM GV$SGA_DYNAMIC_COMPONENTS
order by 1;

PROMPT
PROMPT <P><P><h3>Oracle SGA Summary</h3>
COLUMN "SGA COMPONENT NAME"   FORMAT A20
COLUMN "SIZE (MB)"            FORMAT 999,999,999,999

BREAK ON INST_ID
COMPUTE SUM LABEL "WHOLE SGA SIZE" OF VALUE "SIZE (MB)" ON INST_ID

SELECT INST_ID,
	NAME "SGA COMPONENT NAME",
       VALUE/(1024*1024) "SIZE (MB)" 
FROM   GV$SGA 
Where  INST_ID = 1;
PROMPT

SELECT INST_ID,
	NAME "SGA COMPONENT NAME",
       VALUE/(1024*1024) "SIZE (MB)" 
FROM   GV$SGA 
Where  INST_ID = 2;
PROMPT

SELECT INST_ID,
	NAME "SGA COMPONENT NAME",
       VALUE/(1024*1024) "SIZE (MB)" 
FROM   GV$SGA 
Where  INST_ID = 3;
PROMPT

SELECT INST_ID,
	NAME "SGA COMPONENT NAME",
       VALUE/(1024*1024) "SIZE (MB)" 
FROM   GV$SGA 
Where  INST_ID = 4;
PROMPT

SELECT INST_ID,
	NAME "SGA COMPONENT NAME",
       VALUE/(1024*1024) "SIZE (MB)" 
FROM   GV$SGA 
Where  INST_ID = 5;
PROMPT

SELECT INST_ID,
	NAME "SGA COMPONENT NAME",
       VALUE/(1024*1024) "SIZE (MB)" 
FROM   GV$SGA 
Where  INST_ID = 6;
PROMPT

SELECT INST_ID,
	NAME "SGA COMPONENT NAME",
       VALUE/(1024*1024) "SIZE (MB)" 
FROM   GV$SGA 
Where  INST_ID = 7;
PROMPT

SELECT INST_ID,
	NAME "SGA COMPONENT NAME",
       VALUE/(1024*1024) "SIZE (MB)" 
FROM   GV$SGA 
Where  INST_ID = 8;

CLEAR COLUMNS;

PROMPT
PROMPT <P><P><h3>Oracle SGA dynamic component sizes, In Bytes</h3>
COLUMN "COMPONENT"                            FOR a30
COLUMN "CURRENT SIZE (MB)"                FOR 9,999,999,999
COLUMN "MIN SIZE (MB)"                          FOR 9,999,999,999
COLUMN "MAX SIZE (MB)"                         FOR 9,999,999,999
COLUMN "LAST_OPER_TYPE"                    FOR a20
COLUMN "LAST_OPER_MODE"                 FOR a20
COLUMN "LAST_OPER_TIME"                    FOR a20
COLUMN "Ops per day"                                FOR 999,999,999.9
COMPUTE SUM LABEL "Total" OF VALUE "CURRENT SIZE (MB)" ON REPORT
COMPUTE SUM LABEL "Total" OF VALUE "MIN SIZE (MB)" ON REPORT
COMPUTE SUM LABEL "Total" OF VALUE "MAX SIZE (MB)" ON REPORT
BREAK ON INST_ID

SELECT a.INST_ID,       
                a.COMPONENT,                               
                a.CURRENT_SIZE/(1024*1024) "CURRENT SIZE (MB)", 
                a.MIN_SIZE/(1024*1024) "MIN SIZE (MB)",          
                a.MAX_SIZE/(1024*1024) "MAX SIZE (MB)",
                a.OPER_COUNT,
                a.OPER_COUNT/(sysdate - (select startup_time from gv$instance  where inst_id = a.inst_id)) "Ops per day",     
                a.LAST_OPER_TYPE,                       
                a.LAST_OPER_MODE,    
                a.LAST_OPER_TIME
FROM                   GV$SGA_DYNAMIC_COMPONENTS a
WHERE                 a.MAX_SIZE > 0
order by 1,upper(a.COMPONENT)
;

PROMPT
PROMPT <P><P><h3>Segments in non-Default Buffer Pools </h3>
COLUMN buffer_pool FORMAT a20
BREAK ON buffer_pool
COMPUTE SUM LABEL "Total Segment Size" OF VALUE "Segment Size (MB)" ON buffer_pool

SELECT buffer_pool, SEGMENT_NAME, bytes/1024/1024 "Segment Size (MB)"
FROM   DBA_SEGMENTS
WHERE buffer_pool <> 'DEFAULT'
ORDER BY 1,3;

PROMPT
PROMPT <h2 id="Section2">Tablespace Information</h2>

PROMPT <P><P><h3>Disk Group Information</h3><P>

SELECT 	GROUP_NUMBER, NAME, 
	SECTOR_SIZE, BLOCK_SIZE,
	ALLOCATION_UNIT_SIZE, STATE, 
	TYPE, TOTAL_MB
FROM V$ASM_DISKGROUP
ORDER BY 1,2
/

PROMPT
PROMPT <P><P><h3>Tablespace Storage Configuration</h3><P>
COLUMN "INIT (KB)"                            FORMAT 999,999,999
COLUMN "NEXT (KB)"                            FORMAT 999,999,999
COLUMN  ALLOCATION_TYPE                       FORMAT A15
COLUMN "EXTENT MANAGEMENT"         		    FORMAT A18 HEADING 'EXTENT | MANAGEMENT'
COLUMN "EXTENT ALLOCATION TYPE"               FORMAT A25 HEADING 'EXTENT | ALLOCATION | TYPE'
COLUMN "CONTENT TYPE"                         FORMAT A15 HEADING 'CONTENT | TYPE'
COLUMN "SEGMENT SPACE MANAGEMENT"             FORMAT A15 HEADING 'SEGMENT | SPACE | MANAGEMENT'

SELECT TABLESPACE_NAME "TABLESPACE",
	BLOCK_SIZE, 
       INITIAL_EXTENT/1024 "INIT (KB)" , 
       NVL(NEXT_EXTENT, INITIAL_EXTENT)/1024 "NEXT (KB)" , 
       CASE WHEN MAX_EXTENTS > 2000000000 THEN 'UNLIMITED' 
            ELSE TO_CHAR(MAX_EXTENTS,'999,999,999,999') END "MAX EXTENTS",
       CONTENTS "CONTENT_TYPE", 
       ALLOCATION_TYPE "EXTENT ALLOCATION TYPE",
       LOGGING,
       EXTENT_MANAGEMENT "EXTENT MANAGEMENT", 
       SEGMENT_SPACE_MANAGEMENT "SEGMENT SPACE MANAGEMENT"
FROM   DBA_TABLESPACES 
ORDER  BY TABLESPACE_NAME ;
CLEAR COLUMNS ;

PROMPT
PROMPT <P><P><h3>Tablespace Space Allocation and Utilization</h3>
BREAK ON REPORT;
CLEAR COLUMNS
COLUMN TABLESPACE FORMAT A20
COLUMN TOTAL_MB FORMAT 999,999,999,999.99
COLUMN USED_MB FORMAT 999,999,999,999.99
COLUMN FREE_MB FORMAT 999,999,999.99
COLUMN PCT_USED FORMAT 999.99
COLUMN STATUS FORMAT A10
COMPUTE SUM OF TOTAL_MB ON REPORT
COMPUTE SUM OF USED_MB ON REPORT
COMPUTE SUM OF FREE_MB ON REPORT
BREAK ON REPORT 

SELECT  TOTAL.TS TABLESPACE,
        DECODE(TOTAL.MB,NULL,'OFFLINE',DBAT.STATUS) STATUS,
	  TOTAL.MB TOTAL_MB,
	  NVL(TOTAL.MB - FREE.MB,TOTAL.MB) USED_MB,
	  NVL(FREE.MB,0) FREE_MB,
        DECODE(TOTAL.MB,NULL,0,NVL(ROUND((TOTAL.MB - FREE.MB)/      (TOTAL.MB)*100,2),100)) PCT_USED
FROM
	(SELECT TABLESPACE_NAME TS, SUM(BYTES)/1024/1024 MB 
       FROM DBA_DATA_FILES GROUP BY TABLESPACE_NAME) TOTAL,
	(SELECT TABLESPACE_NAME TS, SUM(BYTES)/1024/1024 MB 
       FROM DBA_FREE_SPACE GROUP BY TABLESPACE_NAME) FREE,
       DBA_TABLESPACES DBAT
WHERE TOTAL.TS=FREE.TS(+) AND
      TOTAL.TS=DBAT.TABLESPACE_NAME
UNION ALL
SELECT  SH.TABLESPACE_NAME, 
        'TEMP',
	 SUM(SH.BYTES_USED+SH.BYTES_FREE)/1024/1024 TOTAL_MB,
	 SUM(SH.BYTES_USED)/1024/1024 USED_MB,
	 SUM(SH.BYTES_FREE)/1024/1024 FREE_MB,
        ROUND(SUM(SH.BYTES_USED)/SUM(SH.BYTES_USED+SH.BYTES_FREE)* 100,2) PCT_USED
FROM V$TEMP_SPACE_HEADER SH
GROUP BY TABLESPACE_NAME
ORDER BY 1
/

CLEAR COLUMNS;
CLEAR BREAKS;
CLEAR COMPUTES;

PROMPT
PROMPT <P><P><h3>Tablespace Datafile Sizes and Configuration</h3>
BREAK ON TABLESPACE SKIP 1
COLUMN "SIZE (MB)"  FORMAT 999,999,999
COLUMN "BLOCKS"     FORMAT 999,999,999
COLUMN "FILE_NAME"  FORMAT A50
COLUMN "AUTOEXTEND" FORMAT A10

SELECT TABLESPACE_NAME "TABLESPACE", 
       FILE_NAME       "FILE NAME", 
       BYTES/(1024*1024) "SIZE (MB)",
       BLOCKS,
       STATUS,
       AUTOEXTENSIBLE "AUTOEXTEND"
FROM   DBA_DATA_FILES
UNION
SELECT TABLESPACE_NAME "TABLESPACE", 
       FILE_NAME       "FILE NAME", 
       BYTES/(1024*1024) "SIZE (MB)",
       BLOCKS,
       STATUS,
       AUTOEXTENSIBLE "AUTOEXTEND"
FROM   DBA_TEMP_FILES
ORDER  BY 1;
CLEAR COLUMNS ;
CLEAR BREAKS;

PROMPT
PROMPT <P><P><h3>I/O Distribution Across Datafiles</h3><P>
BREAK ON TABLESPACE_NAME SKIP 1
COLUMN FILE_NAME                        FOR A50
COLUMN "TOTAL IO"				    FOR 999,999,999,999
COLUMN PHYRDS                           FOR 999,999,999,999
COLUMN PHYWRTS                          FOR 999,999,999,999
COLUMN PHYBLKRD                         FOR 999,999,999,999
COLUMN "READ_TIME (s)"                  FOR 999,999,999,999
COLUMN "WRITE_TIME (s)"                 FOR 999,999,999,999
COLUMN "PCT OF TOTAL PHYRDS"              FOR 999.9
COLUMN "PCT OF TOTAL PHYWRTS"             FOR 999.9
COLUMN "Avg Readtime per PHYRDS (ms)"   FOR 999,999
COLUMN "Avg writetime per PHYWRTS (ms)" FOR 999,999

SELECT 	TABLESPACE_NAME,       		
	FILE_NAME,        
	PHYRDS,       
	PHYRDS*100/TOTAL_PHYRDS  "PCT OF TOTAL PHYRDS",
       	READTIM "READ_TIME (s)",       	
	READTIM*10/decode (PHYRDS, 0, 1, PHYRDS) "Avg Readtime per PHYRDS (ms)",
       	PHYWRTS,       
	PHYWRTS*100/TOTAL_PHYWRTS "PCT OF TOTAL PHYWRTS",      
	WRITETIM "WRITE_TIME (s)",       
	WRITETIM*10/decode (PHYWRTS, 0, 1, PHYWRTS) "Avg writetime per PHYWRTS (ms)"
FROM   	V$FILESTAT FS, 
       	DBA_DATA_FILES DF,
       	(select SUM(PHYRDS)          TOTAL_PHYRDS,               SUM(PHYWRTS)         TOTAL_PHYWRTS,
               NVL(SUM(READTIM), 1) TOTAL_READ_TIME,               NVL(SUM(READTIM), 1) TOTAL_READ_TIME
        from   V$FILESTAT        )
WHERE  	FS.FILE# = DF.FILE_ID
ORDER BY TABLESPACE_NAME, FILE_NAME;

CLEAR BREAKS;
CLEAR COLUMNS;

PROMPT
PROMPT <h2 id="Section3">Redo and UNDO Information</h2>

PROMPT
PROMPT <P><P><h3>Redo Log Configuration</h3>
COLUMN MEMBER FORMAT A50
COLUMN IS_RECOVERY_DEST_FILE FOR A22
BREAK ON INST_ID

SELECT *
FROM   V$LOGFILE
ORDER  BY GROUP#, MEMBER 
;

PROMPT
PROMPT <P><P><h3>Current Status of Redo Log files</h3><P>
COLUMN "SIZE (MB)"              FORMAT 999,999,999,999.99
COLUMN FIRST_CHANGE_TIMESTAMP   FORMAT A25

SELECT Inst_id,
	GROUP#, 
       THREAD#, 
       SEQUENCE#, 
       BYTES/(1024*1024) "SIZE (MB)", 
       MEMBERS, 
       ARCHIVED, 
       STATUS, 
       FIRST_CHANGE#, 
       TO_CHAR(FIRST_TIME, 'MON-DD-YYYY HH24:MM:SS') FIRST_CHANGE_TIMESTAMP
FROM   GV$LOG 
WHERE  INST_ID = THREAD#	 
ORDER BY 1,2,3,4
/

PROMPT
PROMPT <P><P><h3>Frequency of Log Switches </h3>

SELECT inst_id,SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),1,5) DAY, 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'00',1,0)),'999') "00", 
	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'01',1,0)),'999') "01", 
 	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'02',1,0)),'999') "02", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'03',1,0)),'999') "03", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'04',1,0)),'999') "04", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'05',1,0)),'999') "05", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'06',1,0)),'999') "06", 
  	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'07',1,0)),'999') "07", 
	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'08',1,0)),'999') "08", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'09',1,0)),'999') "09", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'10',1,0)),'999') "10", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'11',1,0)),'999') "11", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'12',1,0)),'999') "12", 
  	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'13',1,0)),'999') "13", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'14',1,0)),'999') "14", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'15',1,0)),'999') "15", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'16',1,0)),'999') "16", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'17',1,0)),'999') "17", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'18',1,0)),'999') "18", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'19',1,0)),'999') "19", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'20',1,0)),'999') "20", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'21',1,0)),'999') "21", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'22',1,0)),'999') "22", 
   	 TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME, 'HH24'),'23',1,0)),'999') "23" 
FROM 	 GV$LOG_HISTORY 
WHERE    FIRST_TIME >= SYSDATE - 30 
and  INST_ID = THREAD#	 
GROUP BY inst_id, SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),1,5)
ORDER BY inst_id, SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),1,5)
;

PROMPT
PROMPT <P><P><h3>UNDO Segment Status</h3>
COLUMN "TABLESPACE_NAME" FORMAT A15
COLUMN "SEGMENT_NAME"    FORMAT A12
COLUMN "INIT_EXT (KB)"   FORMAT 999,999,999
COLUMN "NEXT_EXT (KB)"   FORMAT 999,999,999
COLUMN "MIN_EXTENTS"     FORMAT 99
COLUMN "MAX_EXTENTS"     FORMAT 999,999,999
COLUMN STATUS            FORMAT A9

SELECT 
      STATUS,
	count(*)
FROM DBA_ROLLBACK_SEGS
group by STATUS;

PROMPT
PROMPT <h2 id="Section4">Schema Information</h2>

PROMPT
PROMPT <P><P><h3>Table Count by Schema/Owner and Tablespaces</h3><P>
COLUMN NO_OF_TABLES FORMAT 999,999

SELECT OWNER, 
       TABLESPACE_NAME,
       COUNT(1) NO_OF_TABLES
FROM   DBA_TABLES
GROUP  BY OWNER, TABLESPACE_NAME
ORDER  BY OWNER, TABLESPACE_NAME ;   

CLEAR COLUMNS;

PROMPT
PROMPT <P><P><h3>Index Count by Schema/Owner and Tablespaces</h3>
COLUMN NO_OF_INDEXES FORMAT 999,999

SELECT OWNER, 
       TABLESPACE_NAME,
       COUNT(1) NO_OF_INDEXES
FROM   DBA_INDEXES
GROUP  BY OWNER, TABLESPACE_NAME
ORDER  BY OWNER, TABLESPACE_NAME ;

PROMPT
PROMPT <P><P><h3>Index Count by Schema/Owner and Type </h3>

select owner, index_type, count(*) NO_OF_INDEXES from dba_indexes
group by owner, index_type
order by owner, index_type;

PROMPT
PROMPT <P><P><h3> Siebel Tables with largest size (More than 1GB) </h3>
column "size_MB" for 999,999,999,999

SELECT segment_name, 
                sum(bytes/1024/1024) "size_MB", 
                segment_type, 
                tablespace_name
FROM   dba_segments
WHERE  owner=UPPER('&TABLE_OWNER')
and    (segment_type = 'TABLE' or segment_type = 'TABLE PARTITION')
and    segment_name not like 'BIN%%'
group by segment_name,segment_type, tablespace_name
having sum(bytes/1024/1024) > 999
order by 2 desc;

PROMPT
PROMPT <P><P><h3> Siebel Indexes with largest size (More than 1GB) </h3>

SELECT segment_name, 
                sum(bytes/1024/1024) "size_MB", 
                segment_type, 
                tablespace_name
FROM   dba_segments
WHERE   owner=UPPER('&TABLE_OWNER')
and        (segment_type = 'INDEX' or segment_type = 'INDEX PARTITION')
and        segment_name not like 'BIN%%'
group by segment_name,segment_type, tablespace_name
having sum(bytes/1024/1024) > 999
order by 2 desc;

PROMPT
PROMPT <P><P><h3> Siebel Tables with most number of rows (more than 1 million rows) </h3>
col num_rows for 999,999,999,999
col last_analyzed for a30

select table_name, num_rows, avg_row_len, last_analyzed 
from dba_tables
where owner=UPPER('&TABLE_OWNER')
and num_rows > 999999
order by 2 desc;

PROMPT
PROMPT <P><P><h3>Parallel Degree Settings for Siebel tables - total</h3><P>

SELECT           DEGREE,
                count(*)
FROM            DBA_TABLES
WHERE  OWNER = UPPER('&TABLE_OWNER')
group by degree
order by 1;

PROMPT
PROMPT <P><P><h3>Parallel Degree Settings for Siebel tables (Other than 0 or 1) - detail</h3><P>
PROMPT Comments: limited 200 objects in the following list

select * from (
SELECT TABLE_NAME,       
                DEGREE
FROM                   DBA_TABLES
WHERE   trim(DEGREE) <>'0' and trim(DEGREE) <> '1' and DEGREE is not NULL
and        OWNER = UPPER('&TABLE_OWNER')
ORDER  BY TABLE_NAME)
where rownum < 201;

PROMPT
PROMPT <P><P><h3>Parallel Degree Settings for Siebel indexes - total</h3><P>

SELECT DEGREE,
                count(*)
FROM                   DBA_INDEXES
WHERE  OWNER = UPPER('&TABLE_OWNER')
group by degree
order by 1;

PROMPT
PROMPT <P><P><h3>Parallel Degree Settings for Siebel indexes (Other than 0 or 1) - detail</h3><P>
PROMPT Comments: limited 200 objects in the following list

select * from (
SELECT INDEX_NAME,       
                DEGREE
FROM                   DBA_INDEXES
WHERE   trim(DEGREE) <>'0' and trim(DEGREE) <> '1' and DEGREE is not NULL
and        OWNER = UPPER('&TABLE_OWNER')
ORDER  BY TABLE_NAME)
where rownum < 201;

PROMPT
PROMPT <P><P><H3> Dropped Segments (>100MB) </H3>
col size_MB for 999,999,999

select segment_name, bytes/1024/1024 "size_MB"
from dba_segments
where owner=UPPER('&TABLE_OWNER')
and segment_name like 'BIN%'
and bytes/1024/1024 > 99
order by 2 desc
/

PROMPT
PROMPT <P><P><h3> Miscellaneous Siebel table rows </h3>

select table_name, num_rows, last_analyzed
from dba_tables
where 
owner = UPPER('&TABLE_OWNER')
and
table_name in 
('CX_AUDIT_ITEM',
'S_AUDIT_ITEM',
'S_DIAG',
'S_DIAG_DATA',
'S_DIAG_DTL',
'S_DOCK_TXN_LOG',
'S_DOCK_TXN_SET',
'S_ESCL_REQ',
'S_ESCL_LOG',
'S_SRM_REQUEST',
'S_SRM_REQ_PARAM',
'S_SRM_ACTION',
'S_SRM_DATA',
'S_SRM_TASK_HIST',
'S_WFA_INST_LOG', 
'S_WFA_INSTP_LOG', 
'S_WFA_STPRP_LOG'
)
order by table_name
;

PROMPT
PROMPT <P><P><h3> Miscellaneous Siebel Segment Space </h3>

select segment_name, sum(bytes)/1024/1024 "size_MB"
from dba_segments
where 
owner = UPPER('&TABLE_OWNER')
and
segment_name in 
('CX_AUDIT_ITEM',
'S_AUDIT_ITEM',
'S_DIAG',
'S_DIAG_DATA',
'S_DIAG_DTL',
'S_DOCK_TXN_LOG',
'S_DOCK_TXN_SET',
'S_ESCL_REQ',
'S_ESCL_LOG',
'S_SRM_REQUEST',
'S_SRM_REQ_PARAM',
'S_SRM_ACTION',
'S_SRM_DATA',
'S_SRM_TASK_HIST',
'S_WFA_INST_LOG', 
'S_WFA_INSTP_LOG', 
'S_WFA_STPRP_LOG'
)
group by segment_name
order by segment_name
;

PROMPT
PROMPT <P><P><h3>Backlog in S_ESCL_REQ table for workflow policies</h3>
COLUMN RULE_ID                                         FORMAT A10
COLUMN NO_OF_PENDING_ESCALATIONS FORMAT 999,999,999
COLUMN WORKFLOW_POLICY                     FORMAT A40

SELECT RULE_ID, 
       COUNT(1) NO_OF_PENDING_ESCALATIONS, 
       RULE.NAME WORKFLOW_POLICY
FROM   &TABLE_OWNER..S_ESCL_REQ REQ, 
       &TABLE_OWNER..S_ESCL_RULE RULE 
WHERE  REQ.RULE_ID = RULE.ROW_ID 
GROUP  BY RULE_ID, NAME 
ORDER  BY 2 DESC ;

PROMPT
PROMPT <P><P><h3>Backlog in S_SRM_REQUEST table for workflow policies</h3>
COLUMN RULE_ID                                         FORMAT A10
COLUMN NO_OF_PENDING_ESCALATIONS FORMAT 999,999,999
COLUMN WORKFLOW_POLICY                     FORMAT A40

SELECT Status, count(*) 
FROM   &TABLE_OWNER..S_SRM_REQUEST
GROUP  BY STATUS 
;

PROMPT
PROMPT <P><P><h3>Segment Fragmentation by extents</h3>
COL segment_name FOR 	a25
COL segment_type FOR 	a12
COL tablespace_name FOR a15
col "size (GB)" for 999,999
col extents for 999,999,999

SELECT segment_name,segment_type,bytes/1024/1024/1024 "size (GB)", extents,tablespace_name
FROM   dba_segments
WHERE  owner = upper('&&table_owner')
and    extents > 9999
order  by extents desc;
CLEAR COLUMNS

PROMPT
PROMPT <P><P><h3>Count of triggers by table on Siebel Schema </h3>

SELECT TABLE_OWNER, 
       TABLE_NAME, 
       COUNT(1) NO_OF_TRIGGERS
FROM   DBA_TRIGGERS
WHERE  TABLE_OWNER = UPPER('&TABLE_OWNER') 
GROUP  BY TABLE_OWNER, TABLE_NAME
ORDER  BY TABLE_OWNER, TABLE_NAME ;

PROMPT
PROMPT <P><P><h3>Sequences in Siebel Schema </h3>
COLUMN SEQUENCE_OWNER FORMAT a15
COLUMN SEQUENCE_NAME FORMAT a25
COLUMN INCR FORMAT 999
COLUMN CYCLE FORMAT A5
COLUMN ORDER FORMAT A5

SELECT SEQUENCE_OWNER,
 	 SEQUENCE_NAME,
 	 MIN_VALUE,
 	 MAX_VALUE,
 	 INCREMENT_BY INCR,
 	 CYCLE_FLAG CYCLE,
 	 ORDER_FLAG "ORDER",
 	 CACHE_SIZE,
 	 LAST_NUMBER
  FROM DBA_SEQUENCES
 WHERE SEQUENCE_OWNER=UPPER('&TABLE_OWNER');

PROMPT
PROMPT <P><P><h3>Services </h3>

SELECT SERVICE_ID,
	NAME,
	NETWORK_NAME,
	FAILOVER_METHOD,
	FAILOVER_TYPE,
	FAILOVER_RETRIES,
	FAILOVER_DELAY,
	GOAL,
	ENABLED
FROM DBA_SERVICES
/

PROMPT
PROMPT <h2 id="Section5">Optimizer Statistics Information</h2>
CLEAR COLUMNS;
PROMPT <P><P><h3>Oracel 10g Scheduled Stats Job</h3><P>

SELECT 
   a.job_name, 
   a.enabled, 
   c.window_name, 
   c.schedule_name, 
   c.start_date, 
   c.repeat_interval 
FROM 
   dba_scheduler_jobs             a, 
   dba_scheduler_wingroup_members b, 
   dba_scheduler_windows          c 
WHERE 
   job_name='GATHER_STATS_JOB' 
And 
   a.schedule_name=b.window_group_name 
And 
   b.window_name=c.window_name; 

PROMPT
PROMPT <P><P><h3>Oracle 11g/12c Auto Stats Tasks</h3><P>

SELECT 
	client_name, 
	status, 
	consumer_group, 
	mean_job_duration
FROM dba_autotask_client
WHERE client_name = 'auto optimizer stats collection';

PROMPT
PROMPT <P><P><h3>System Statistics Information</h3><P>
PROMPT Comments
PROMPT => sreadtim : wait time to read single block, in milliseconds 
PROMPT => mreadtim : wait time to read a multiblock, in milliseconds 
PROMPT => cpuspeed : cycles per second, in millions 


select pval2 from sys.aux_stats$ where sname = 'SYSSTATS_INFO' and pname = 'STATUS';

PROMPT
select pname, pval1 from sys.aux_stats$ where sname = 'SYSSTATS_MAIN';

PROMPT
select * from sys.aux_stats$;

PROMPT
PROMPT <P><P><h3>Count of tables that have statistics</h3><P>
COLUMN NO_OF_TABLES_WITH_STATS FORMAT 999,999

SELECT OWNER, 
       COUNT(1) NO_OF_TABLES_WITH_STATS
FROM   DBA_TABLES
WHERE  LAST_ANALYZED IS NOT NULL
GROUP  BY OWNER
ORDER  BY OWNER;    

PROMPT
PROMPT <P><P><h3>Count of indexes that have statistics</h3>
COLUMN NO_OF_INDEXES_WITH_STATS FORMAT 999,999

SELECT OWNER, 
       COUNT(1) NO_OF_INDEXES_WITH_STATS
FROM   DBA_INDEXES
WHERE  LAST_ANALYZED IS NOT NULL
GROUP  BY OWNER
ORDER  BY OWNER;

PROMPT
PROMPT <P><P><h3>Last analyzed time for Siebel tables</h3><P>

SELECT  
       TRUNC(LAST_ANALYZED) LAST_ANALYZED,
       COUNT(1) NO_OF_TABLES
FROM   DBA_TABLES
WHERE  OWNER = UPPER('&TABLE_OWNER')
GROUP  BY TRUNC(LAST_ANALYZED)
ORDER BY LAST_ANALYZED;


PROMPT
PROMPT <P><P><h3>Last analyzed time for Siebel indexes</h3><P>

SELECT TRUNC(LAST_ANALYZED) LAST_ANALYZED,
       COUNT(1) NO_OF_INDEXES
FROM   DBA_INDEXES
WHERE  OWNER = UPPER('&TABLE_OWNER')
GROUP  BY TRUNC(LAST_ANALYZED)
ORDER BY LAST_ANALYZED;

PROMPT
PROMPT <P><P><h3>Count of near-EMPTY Siebel tables (<= 15 rows) that have statistics</h3><P>
PROMPT - Comments: EIM, DOCK, SRM, ESCL, ETL, and etc tables are excluded below.
PROMPT 
COLUMN NEAR_EMPTY_TABLES_WITH_STATS FORMAT 999,999

SELECT COUNT(1) NEAR_EMPTY_TABLES_WITH_STATS
FROM   DBA_TABLES
WHERE  LAST_ANALYZED IS NOT NULL AND 
	NUM_ROWS <= 15 AND OWNER = UPPER('&TABLE_OWNER')
and    (table_name like 'S\_%' escape '\'
or	table_name like 'CX\_%' escape '\')
and   (table_name not like 'EIM\_%' escape '\'
and    table_name not like 'S\_DCK%' escape '\'
and    table_name not like 'S\_DOCK%' escape '\'
and    table_name not like 'S\_ESCL\_REQ%' escape '\'
and    table_name not like 'S\_SRM\_REQUEST%' escape '\'
and    table_name not like 'S\_UPG%' escape '\'
and    table_name not like 'S\_ETL%' escape '\')
;

PROMPT
PROMPT <P><P><h3>Example of near-EMPTY Siebel tables that have statistics</h3><P>
PROMPT- Comments: show only 200 tables below
PROMPT
COLUMN EMPTY_TABLES_WITH_STATS FORMAT 999,999

SELECT * FROM (
SELECT TABLE_NAME, NUM_ROWS
FROM   DBA_TABLES
WHERE  LAST_ANALYZED IS NOT NULL AND 
	(NUM_ROWS >= 0 and NUM_ROWS < 16) AND OWNER = UPPER('&TABLE_OWNER')
and    (table_name like 'S\_%' escape '\'
or	table_name like 'CX\_%' escape '\')
and   (table_name not like 'EIM\_%' escape '\'
and    table_name not like 'S\_DCK%' escape '\'
and    table_name not like 'S\_DOCK%' escape '\'
and    table_name not like 'S\_ESCL\_REQ%' escape '\'
and    table_name not like 'S\_SRM\_REQUEST%' escape '\'
and    table_name not like 'S\_UPG%' escape '\'
and    table_name not like 'S\_ETL%' escape '\')
ORDER BY 1)
WHERE ROWNUM < 201
;

PROMPT
PROMPT <P><P><h3>Stats for Key Siebel Tables</h3><P>
PROMPT- Comments: See section of "Additional Information"

PROMPT
PROMPT <h2 id="Section6">Basic Database Performance Information</h2>
Break on INST_ID

PROMPT <P><P><h3>Current SGA Library Summary</h3>
COLUMN LIBRARY 		FORMAT A15 HEADING 'LIBRARY|NAME'
COLUMN GETS 		FORMAT 999,999,999,999 
COLUMN GETHITRATIO	FORMAT 990.99 
COLUMN PINS 		FORMAT 999,999,999,999 
COLUMN PINHITRATIO 	FORMAT 990.99 
COLUMN RELOADS 		FORMAT 999,999,999 
COLUMN INVALIDATIONS 	FORMAT 999,999,999 
SELECT INST_ID,
       INITCAP(NAMESPACE) LIBRARY, 
       GETS , 
       GETHITRATIO, 
       PINS , 
       PINHITRATIO , 
       RELOADS , 
	INVALIDATIONS 
  FROM GV$LIBRARYCACHE
order by 1,2 
/ 

PROMPT
PROMPT <P><P><h3>Library hit ratio</h3>
COLUMN LIBRARY_HIT_RATIO      FORMAT 999.99
COLUMN EXECUTIONS             FORMAT 999,999,999,999
COLUMN CACHE_MISSES           FORMAT 999,999,999,999

SELECT INST_ID,
	SUM(PINS)    EXECUTIONS,
       SUM(RELOADS) CACHE_MISSES,
       (1 - (SUM(RELOADS)/SUM(PINS))) LIBRARY_HIT_RATIO
FROM   GV$LIBRARYCACHE
GROUP BY INST_ID
order by inst_id;

PROMPT
PROMPT <P><P><h3>Data Dictionary hit ratio</h3>
COLUMN DATA_DICTIONARY_MISSES FORMAT 999,999,999,999,999
COLUMN DATA_DICTIONARY_GETS   FORMAT 999,999,999,999,999
COLUMN DATA_DICT_HIT_RATIO    FORMAT 999.99

SELECT INST_ID,
	SUM(GETS) DATA_DICTIONARY_GETS,
       SUM(GETMISSES) DATA_DICTIONARY_MISSES,
       (1 - (SUM(GETMISSES)/SUM(GETS))) DATA_DICT_HIT_RATIO
FROM   GV$ROWCACHE 
GROUP BY INST_ID
order by inst_id;


PROMPT
PROMPT <P><P><h3>Default Buffer Pool hit ratio</h3>
COLUMN DEFAULT_BUFFER_POOL_HIT_RATIO FORMAT 999.99
COLUMN PHYSICAL_READS                FORMAT 999,999,999,999,999
COLUMN DB_BLOCK_GETS                 FORMAT 999,999,999,999,999
COLUMN CONSISTENT_GETS               FORMAT 999,999,999,999,999
COLUMN KEEP_BUFFER_POOL_HIT_RATIO    FORMAT 999.99
COLUMN RECYCLE_BUFFER_POOL_HIT_RATIO FORMAT 999.99

SELECT INST_ID,
	PHYSICAL_READS, 
       DB_BLOCK_GETS, 
       CONSISTENT_GETS, 
       (1-(PHYSICAL_READS/(DB_BLOCK_GETS+CONSISTENT_GETS))) DEFAULT_BUFFER_POOL_HIT_RATIO
FROM   GV$BUFFER_POOL_STATISTICS 
WHERE  NAME = 'DEFAULT' AND DB_BLOCK_GETS+CONSISTENT_GETS != 0 
order by inst_id;


PROMPT
PROMPT <P><P><h3>Keep Buffer Pool hit ratio</h3>

SELECT INST_ID,
	PHYSICAL_READS, 
       DB_BLOCK_GETS, 
       CONSISTENT_GETS, 
       (1-(PHYSICAL_READS/(DB_BLOCK_GETS+CONSISTENT_GETS))) KEEP_BUFFER_POOL_HIT_RATIO
FROM   GV$BUFFER_POOL_STATISTICS 
WHERE  NAME = 'KEEP' AND DB_BLOCK_GETS+CONSISTENT_GETS != 0 
order by inst_id;

PROMPT
PROMPT <P><P><h3>Recycle buffer pool hit ratio </h3>

SELECT INST_ID,
	PHYSICAL_READS, 
       DB_BLOCK_GETS, 
       CONSISTENT_GETS, 
       (1-(PHYSICAL_READS/(DB_BLOCK_GETS+CONSISTENT_GETS))) RECYCLE_BUFFER_POOL_HIT_RATIO
FROM   GV$BUFFER_POOL_STATISTICS 
WHERE  NAME = 'RECYCLE' AND DB_BLOCK_GETS+CONSISTENT_GETS != 0 
order by inst_id;

PROMPT
PROMPT <P><P><h3>Redo Log Space Requests</h3>

SELECT  INST_ID,
	SUBSTR(NAME,1,25) NAME, 
        SUBSTR(VALUE,1,15) "VALUE" 
  FROM  GV$SYSSTAT 
 WHERE  NAME = 'redo log space requests'
order by inst_id; 

PROMPT
PROMPT <P><P><h3>Latch Contention</h3>
COLUMN LATCH_NAME                FORMAT A25
COLUMN MISSES                    FORMAT 999,999,999,999
COLUMN IMMEDIATE_GETS            FORMAT 999,999,999,999
COLUMN IMMEDIATE_MISSES          FORMAT 999,999,999,999

SELECT  ln.INST_ID,
	SUBSTR(LN.NAME, 1, 20) LATCH_NAME, 
        GETS, 
        MISSES, 
        IMMEDIATE_GETS, 
        IMMEDIATE_MISSES 
  FROM  GV$LATCH l, GV$LATCHNAME ln 
 WHERE  ln.NAME in ('redo allocation', 'redo copy') 
   and  ln.LATCH# = l.LATCH#
   and  ln.inst_id = l.inst_id; 

PROMPT
PROMPT <P><P><h3>Statistics on workarea executions</h3>

SELECT INST_ID,
	NAME,
	 VALUE
  FROM GV$SYSSTAT
 WHERE NAME LIKE 'workarea executions%'
order by 1 ;

PROMPT
PROMPT <P><P><h3>Oracle PGA stats</h3>
COLUMN "NAME"		FOR a30 		
COLUMN "VALUE"		FOR a30 		

SELECT * FROM (
SELECT 	INST_ID,       
	NAME,       	
	trunc(VALUE/1024/1024/1024, 1)||' GB' "VALUE"
FROM   	GV$PGASTAT
WHERE  	NAME IN ('aggregate PGA target parameter','total PGA inuse','total PGA allocated','maximum PGA allocated')
UNION ALL
SELECT 	INST_ID,       
	NAME,       	
	to_char(VALUE)  "VALUE"
FROM   	GV$PGASTAT
WHERE  	NAME IN ('over allocation count','cache hit percentage'))
ORDER BY INST_ID, NAME;

PROMPT
PROMPT <P><P><h3>Buffer Busy Waits in Segments</h3>

select segment_name,object_type,total_buff_busy_waits
from ( select owner||'.'||object_name as segment_name,object_type,
SUM(value) as total_buff_busy_waits
from gv$segment_statistics
where statistic_name in ('buffer busy waits')
and value > 0
GROUP BY owner||'.'||object_name,object_type
order by total_buff_busy_waits desc)
where rownum <=20 ;

PROMPT
PROMPT <P><P><h3>Time Events</h3>

col seconds for 999,999,999
col stat_name for a40
SELECT inst_id, stat_name, value/1000000 seconds 
FROM gv$sys_time_model
where value > 0
ORDER BY inst_id, seconds DESC;

PROMPT
PROMPT <P><P><h3>Contention Statistics from GV$WAITSTAT</h3>

SELECT * 
  FROM GV$WAITSTAT
 WHERE COUNT > 0 
 ORDER BY inst_id,COUNT DESC ;

PROMPT
PROMPT <P><P><h3>Statistics metrics/values from GV$RESOURCE_LIMIT </h3>

SELECT *
FROM   GV$RESOURCE_LIMIT
order by inst_id, resource_name;

PROMPT
PROMPT <P><P><h3>V$SYSSTAT and V$SYSTEM_EVENT</h3><P>
PROMPT- Comments: See section of "Additional Information"

PROMPT
PROMPT <h2 id="Section7">Advisory Information</h2>

PROMPT <P><P><h3>Buffer Cache Advisory</h3>
COLUMN size_for_estimate FORMAT 999,999,999,999 heading 'Cache Size (MB)'
COLUMN buffers_for_estimate FORMAT 999,999,999 heading 'Buffers'
COLUMN estd_physical_read_factor FORMAT 999.90 heading 'Estd Phys|Read Factor'
COLUMN estd_physical_reads FORMAT 999,999,999,999 heading 'Estd Phys| Reads'

SELECT inst_id, size_for_estimate, buffers_for_estimate, estd_physical_read_factor, estd_physical_reads
FROM GV$DB_CACHE_ADVICE
WHERE name = 'DEFAULT'
AND block_size = (SELECT value FROM V$PARAMETER WHERE name = 'db_block_size')
AND advice_status = 'ON'
order by inst_id, size_for_estimate;

PROMPT
PROMPT <P><P><h3>Shared Pool Advisory</h3>
COLUMN estd_lc_time_saved FORMAT 999,999,999,999 heading 'Time Saved in sec'

SELECT inst_id, shared_pool_size_for_estimate "Size of Shared Pool in MB",
       shared_pool_size_factor "Size Factor",
       estd_lc_time_saved
       FROM gv$shared_pool_advice
order by 1,2;

PROMPT
PROMPT <P><P><h3>SGA Target Advisory </h3>

SELECT * from GV$SGA_TARGET_ADVICE
order by inst_id, sga_size;

PROMPT
PROMPT <P><P><h3>PGA Target Advisory</h3>

SELECT inst_id,
	round(PGA_TARGET_FOR_ESTIMATE/1024/1024) target_mb,
       ESTD_PGA_CACHE_HIT_PERCENTAGE cache_hit_perc,
       ESTD_OVERALLOC_COUNT
  FROM GV$PGA_TARGET_ADVICE
order by 1,2;

PROMPT
PROMPT <P><P><h3>PGA Target Advise Histogram </h3>

SELECT inst_id,LOW_OPTIMAL_SIZE/1024 low_kb, (HIGH_OPTIMAL_SIZE+1)/1024 high_kb, 
       estd_optimal_executions estd_opt_cnt, 
       estd_onepass_executions estd_onepass_cnt, 
       estd_multipasses_executions estd_mpass_cnt 
  FROM gv$pga_target_advice_histogram 
 WHERE pga_target_factor = 2 
   AND estd_total_executions != 0 
 ORDER BY 1,2; 

PROMPT
PROMPT <h2 id="Section8">SQL Performance Information</h2>

PROMPT <P><P><h3>SQL Performance by Elapsed Time per Exec</h3>
col "Elapsed Time per Execution" for a25;
col "elapsed_time_per_exec" for 9,999,999;
COLUMN "Total Executions" for 999,999,999,999,999

select   inst_id, ' 01. Greater than 60 seconds'   "Elapsed Time per Exec"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 60
group by inst_id
union
select   inst_id, ' 02. 10 to 60 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 10
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 60
group by inst_id
union
select   inst_id, ' 03. 9 to 10 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 9
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 10
group by inst_id
union
select   inst_id, ' 04. 8 to 9 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 8
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 9
group by inst_id
union
select   inst_id, ' 05. 7 to 8 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 7
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 8
group by inst_id
union
select   inst_id, ' 06. 6 to 7 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 6
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 7
group by inst_id
union
select   inst_id, ' 07. 5 to 6 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 5
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 6
group by inst_id
union
select   inst_id, ' 08. 4 to 5 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 4
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 5
group by inst_id
union
select   inst_id, ' 09. 3 to 4 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 3
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 4
group by inst_id
union
select   inst_id, ' 10. 2 to 3 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 2
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 3
group by inst_id
union
select   inst_id, ' 11. 1 to 2 seconds'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) >= 1
and	 trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 2
group by inst_id
union
select   inst_id, ' 12. Less than 1 second'   "Elapsed Time per Execution"
, 	trunc(sum(ELAPSED_TIME)/sum(nvl(decode(executions,0,1,executions),1))/1000000) "elapsed_time_per_exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
from     gv$sqlarea
where    trunc(ELAPSED_TIME/nvl(decode(executions,0,1,executions),1)/1000000) < 1
group by inst_id
/

PROMPT
PROMPT <P><P><h3>SQL Performance by Buffer Gets per Exec</h3>
col "Nbr Distinct SQL" for 999,999,999;
col "Total Executions" for 999,999,999;
col "Total Buffer Gets" for 999,999,999,999,999;

select   inst_id, ' 1. Greater than 10M'   "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 10000000
and      executions  >= 1
and      ceil(buffer_gets / executions) > 10000000
group by inst_id
union
select   inst_id, ' 2. 1M to 10M'          "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 1000000
and      executions  >= 1
and      ceil(buffer_gets / executions) between 1000000 and 10000000
group by inst_id
union
select   inst_id, ' 3. 500K to 1M'         "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 500000
and      executions  >= 1
and      ceil(buffer_gets / executions) between 500000 and 999999
group by inst_id
union
select   inst_id, ' 4. 100K to 500K'       "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 100000
and      executions  >= 1
and      ceil(buffer_gets / executions) between 100000 and 499999
group by inst_id
union
select   inst_id, ' 5. 50K to 100K'        "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 50000
and      executions  >= 1
and      ceil(buffer_gets / executions) between 50000 and 99999
group by inst_id
union
select   inst_id, ' 6. 25K to 50K'         "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 25000
and      executions  >= 1
and      ceil(buffer_gets / executions) between 25000 and 49999
group by inst_id
union
select   inst_id, ' 7. 10K to 25K'         "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 10000
and      executions  >= 1
and      ceil(buffer_gets / executions) between 10000 and 24999
group by inst_id
union
select   inst_id, ' 8. 5K to 10K'          "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 5000
and      executions  >= 1
and      ceil(buffer_gets / executions) between 5000 and 9999
group by inst_id
union
select   inst_id, ' 9. 2K to 5K'           "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 2000
and      executions  >= 1
and      ceil(buffer_gets / executions) between 2000 and 4999
group by inst_id
union
select   inst_id, '10. 1K to 2K'           "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 1000
and      executions  >= 1
and      ceil(buffer_gets / executions) between 1000 and 1999
group by inst_id
union
select   inst_id, '11. Less than 1K'       "Buffer Gets per Exec"
,        count(*)                 "Nbr Distinct SQL"
,        sum(executions)          "Total Executions"
,        sum(buffer_gets)         "Total Buffer Gets"
from     gv$sqlarea
where    buffer_gets >= 1
and      executions  >= 1
and      ceil(buffer_gets / executions) <= 999
group by inst_id
/

PROMPT
PROMPT <h2 id="Section9">Oracle Session Information</h2>

PROMPT <P><P><h3>Total Sessions</h3>

select count(*) "Total Sessions" from gv$session
;

PROMPT
PROMPT <P><P><h3>Session Distribution among RAC nodes</h3>

select inst_id, count(*) "Sess_on_Node" from gv$session
GROUP BY inst_id
order by inst_id
;

PROMPT
PROMPT <P><P><h3>Session Distribution among major Machines</h3>

select machine, count(*) "Sess_from_Machine" from gv$session
GROUP BY machine
HAVING count(*) > 4
order by machine
/

PROMPT
PROMPT <P><P><h3>Session Distribution among major Users</h3>

select username, count(*) "Sess_from_User" from gv$session
group by username
having count(*) > 4
order by username
/

PROMPT
PROMPT <P><P><h3>Session Distribution among major program</h3>

select program, count(*) "# of Sessions" from gv$session
group by program
having count(*) > 4
order by program
/

PROMPT

PROMPT <h2 id="Section10">User Information</h2>

PROMPT <P><P><h3>User Definitions</h3>

SELECT Default_Tablespace, Temporary_tablespace, count(*) Number_USERS
FROM   DBA_USERS
Group by Default_Tablespace, Temporary_tablespace
;

PROMPT
PROMPT <P><P><h3>Database users </h3>

SELECT SUM(TOTAL_USERS)        TOTAL_USERS,
       SUM(LOCKED_USER_COUNT)  LOCKED_USER_COUNT,
       SUM(EXPIRED_USER_COUNT) EXPIRED_USER_COUNT
FROM  (
        SELECT COUNT(1) TOTAL_USERS, 
               0        LOCKED_USER_COUNT,
               0        EXPIRED_USER_COUNT
        FROM   DBA_USERS
        UNION
        SELECT 0,
               COUNT(1),
               0
        FROM   DBA_USERS
        WHERE  LOCK_DATE IS NOT NULL
        UNION
        SELECT 0,
               0,
               COUNT(1)
        FROM   DBA_USERS
        WHERE  EXPIRY_DATE IS NOT NULL AND
               EXPIRY_DATE <= SYSDATE 
       ) ;

PROMPT
PROMPT <P><P><h3>Profiles defined in DBA_PROFILES</h3>
COLUMN RESOURCE_TYPE FORMAT A15
BREAK ON PROFILE ON RESOURCE_TYPE

SELECT PROFILE, 
       RESOURCE_TYPE, 
       RESOURCE_NAME, 
       LIMIT
FROM   DBA_PROFILES
ORDER  BY PROFILE, RESOURCE_TYPE ;

PROMPT
PROMPT <P><P><h3>User's profile assignment</h3>
col profile for a30

select profile, count(*) "# of users"
from dba_users
group by profile
order by profile
/

PROMPT
PROMPT <P><P><H3>Roles configured in the database</H3>

SELECT ROLE,
       PASSWORD_REQUIRED
FROM   DBA_ROLES 
order by 1;

PROMPT
PROMPT <P><P><H3>Customer defined Roles </H3>
BREAK ON ROLE

SELECT ROLE NON_BASIC_ROLES,
       PRIVILEGE,
       ADMIN_OPTION
FROM   ROLE_SYS_PRIVS
WHERE ROLE NOT IN ('DBA','IMP_FULL_DATABASE','EXP_FULL_DATABASE','AQ_ADMINISTRATOR_ROLE',
'OEM_ADVISOR','RESOURCE','SCHEDULER_ADMIN','DATAPUMP_EXP_FULL_DATABASE', 'DATAPUMP_IMP_FULL_DATABASE',
'EM_EXPRESS_ALL', 'EM_EXPRESS_BASIC','OLAP_DBA')
order by 1,2;

PROMPT
PROMPT <h2 id="Section11">Siebel Application Information</h2>

PROMPT <P><P><h3>Siebel application schema information</h3>

SELECT APP_VER, 
       DB_SCHEMA_VER, 
       DB_MINOR_VER, 
       CUSTOM_SCHEMA_VER, 
	UNICD_DATATYPS_FLG 
FROM   &TABLE_OWNER..S_APP_VER ;

PROMPT
PROMPT <P><P><h3>Siebel application build information</h3>

SELECT MIN_VERSION, 
       COMMENTS 
FROM   &TABLE_OWNER..S_UPG_COMP 
WHERE  COMMENTS LIKE '%executables%'
ORDER  BY MIN_VERSION ;

PROMPT
PROMPT <P><P><h3>Currently defined repositories in database</h3>

SELECT NAME REPOSITORY_NAME, 
       INACTIVE_FLG, 
       CREATED, 
       LAST_UPD, 
       COMMENTS 
FROM   &TABLE_OWNER..S_REPOSITORY 
ORDER  BY CREATED DESC ;

PROMPT
SELECT COUNT(*) FROM &TABLE_OWNER..S_REPOSITORY;

PROMPT
PROMPT <P><P><h3>Siebel Application System Preferences - Partial list</h3>
PROMPT For complete list, see section of "Additional Information"

SELECT SYS_PREF_CD "SYSTEM PREFERENCES", 
       VAL "VALUE"
FROM   &TABLE_OWNER..S_SYS_PREF
where  SYS_PREF_CD in ('Docking:Transaction Logging',
'BIP Report Wait Time',
'Default MVG Exists Query') 
ORDER  BY SYS_PREF_CD ;

PROMPT
PROMPT <P><P><H3>Cardinality of S_PARTY and related tables</H3>

SELECT S_PARTY_COUNT,
       S_ORG_EXT_COUNT,
       S_CONTACT_COUNT,
       S_EMP_PER_COUNT,
       S_ORG_GROUP_COUNT
FROM   (SELECT NUM_ROWS S_PARTY_COUNT FROM  DBA_TABLES WHERE TABLE_NAME = 'S_PARTY'),
       (SELECT NUM_ROWS S_ORG_EXT_COUNT FROM   DBA_TABLES WHERE TABLE_NAME = 'S_ORG_EXT'),
       (SELECT NUM_ROWS S_CONTACT_COUNT FROM   DBA_TABLES WHERE TABLE_NAME = 'S_CONTACT'),
       (SELECT NUM_ROWS S_EMP_PER_COUNT FROM   DBA_TABLES WHERE TABLE_NAME = 'S_EMP_PER'),
       (SELECT NUM_ROWS S_ORG_GROUP_COUNT FROM   DBA_TABLES WHERE TABLE_NAME = 'S_ORG_GROUP')
       ;

PROMPT
PROMPT <P><P><H3>List of Organization</H3>

SELECT P.NAME
  FROM &TABLE_OWNER..S_PARTY P,
       &TABLE_OWNER..S_BU B
 WHERE P.ROW_ID = B.PAR_ROW_ID
   AND B.BU_FLG = 'Y';

PROMPT
PROMPT <P><P><H3>Number of Positions per Organization</H3>
COL "Organization" FORMAT a50
COL "Nbr Postions" FORMAT 999,999,999

SELECT B.NAME "Organization"
,      count(P.ROW_ID) "Nbr Positions"
FROM   &table_owner..S_BU B
,      &table_owner..S_POSTN P
WHERE  B.ROW_ID = P.BU_ID (+)
AND  ( P.END_DT IS NULL 
OR     P.END_DT >= SYSDATE )
GROUP  BY B.NAME
ORDER  BY B.NAME;

CLEAR COLUMNS
PROMPT
PROMPT <P><P><H3>Number of Responsibilities per Organization</H3>
COL "Organization" FORMAT a50
COL "Nbr Responsibilities" FORMAT 999,999,999 
SELECT B.NAME "ORGANIZATION", 
	 COUNT(R.ROW_ID) "Nbr Responsibilities"
  FROM &TABLE_OWNER..S_RESP R, 
	 &TABLE_OWNER..S_BU B
 WHERE B.ROW_ID = R.BU_ID (+)
 GROUP BY B.NAME
 ORDER BY B.NAME
/

PROMPT
PROMPT <P><P><H3>Employee count in S_EMP_PER</H3>
COLUMN EMP_STAT_CD     FORMAT A15
COLUMN NO_OF_EMPLOYEES FORMAT 999,999,999,999

SELECT EMP_STAT_CD, 
       COUNT(1) NO_OF_EMPLOYEES 
FROM   &TABLE_OWNER..S_EMP_PER 
GROUP  BY EMP_STAT_CD 
ORDER  BY EMP_STAT_CD ;

PROMPT
PROMPT <P><P><h3>Currently defined workflow processes</h3>
COLUMN WORKFLOW_PROCESS FORMAT A60
COLUMN EFF_START_DT              FORMAT A15
COLUMN EFF_END_DT                   FORMAT A15
COLUMN BUSOBJ_NAME               FORMAT A15
COLUMN DESC_TEXT                     FORMAT A30

SELECT COUNT(*) "Number_of_Workflow_processes"
FROM   &TABLE_OWNER..S_WF_STEP 
WHERE  TYPE_CD = 'PROCESS'
and    (EFF_END_DT is null or EFF_END_DT > sysdate)
and    (EFF_START_DT is not null and EFF_START_DT < sysdate)
;

PROMPT
PROMPT <P><P><h3>Currently defined workflow policies and groups</h3>
COLUMN WORKFLOW_GROUP    FORMAT A15
COLUMN WORKFLOW_POLICY    FORMAT A15
COLUMN OBJECT_NAME              FORMAT A12
COLUMN BATCH_FLG                  FORMAT A9
COLUMN QUALIFY_COUNT          FORMAT 999,999,999
COLUMN RULE_DURATION           FORMAT 999,999,999

SELECT WFG.NAME WORKFLOW_GROUP, 
       WFP.NAME WORKFLOW_POLICY, 
       OBJECT_NAME,
       ACTIVATE_DT,
       EXPIRE_DT,       
       BATCH_FLG,  
       QUALIFY_COUNT, 
       RULE_DURATION 
FROM   &TABLE_OWNER..S_ESCL_RULE WFP, 
       &TABLE_OWNER..S_ESCL_GROUP WFG 
WHERE  WFP.GROUP_ID = WFG.ROW_ID AND
       SUB_TYPE_CD = 'Workflow' 
and    (EXPIRE_DT is null or EXPIRE_DT > sysdate)
and    (ACTIVATE_DT is not null and ACTIVATE_DT < sysdate)
ORDER  BY WFG.NAME ;

PROMPT
PROMPT <P><P><h3>Currently defined Assignment rules</h3>
COLUMN NAME                             FORMAT A15
COLUMN ASGN_OBJECT_NAME  FORMAT A16
COLUMN EFF_START_DT             FORMAT A12
COLUMN EFF_END_DT                  FORMAT A10
COLUMN ALL_BU_FLG                 FORMAT A10
COLUMN ALL_EMP_FLG               FORMAT A11
COLUMN ALL_POSTN_FLG          FORMAT A13
COLUMN COMMENTS                    FORMAT A40

SELECT count(*) "Number_of_AM_rules"
FROM   &TABLE_OWNER..S_ASGN_GRP G,
       &TABLE_OWNER..S_ASGN_GRP_OBJ O
WHERE  g.ROW_ID = o.ASGN_GRP_ID
and    (EFF_END_DT is null or EFF_END_DT > sysdate)
and    (EFF_START_DT is not null and EFF_START_DT < sysdate)
;

PROMPT
PROMPT <P><P><h3>Triggers that may be created due assignment rules</h3>
COLUMN WORKFLOW_GRP_FOR_ASSIGNMENT FORMAT A28
COLUMN ASSIGNMENT_RULE                               FORMAT A40
COLUMN BATCH_FLG                                            FORMAT A10
COLUMN OBJECT_NAME                                        FORMAT A12
COLUMN ASGN_OBJECT_NAME                            FORMAT A20

SELECT WFG.NAME WORKFLOW_GRP_FOR_ASSIGNMENT, 
       ACTIVATE_DT,
       EXPIRE_DT,
       WFP.NAME ASSIGNMENT_RULE, 
       BATCH_FLG,       
       OBJECT_NAME, 
       ASGN_OBJECT_NAME
FROM   &TABLE_OWNER..S_ESCL_RULE WFP, 
       &TABLE_OWNER..S_ESCL_GROUP WFG 
WHERE  WFP.GROUP_ID = WFG.ROW_ID AND
       SUB_TYPE_CD = 'Assignment' 
and    (EXPIRE_DT is null or EXPIRE_DT > sysdate)
and    (ACTIVATE_DT is not null and ACTIVATE_DT < sysdate)
ORDER  BY WFG.NAME ;

PROMPT
PROMPT <P><P><h3>Count of customer-created columns In current repository </h3>
COLUMN REPOSITORY_NAME              FORMAT A20
COLUMN TABLE_NAME                         FORMAT A20 
COLUMN NO_OF_CUSTOM_COLUMNS FORMAT 9,999

SELECT R.NAME REPOSITORY_NAME, 
       T.NAME TABLE_NAME, 
       COUNT(1) NO_OF_CUSTOM_COLUMNS 
FROM   &TABLE_OWNER..S_COLUMN C, 
       &TABLE_OWNER..S_REPOSITORY R, 
       &TABLE_OWNER..S_TABLE T	 
WHERE  C.REPOSITORY_ID = R.ROW_ID  AND
       T.REPOSITORY_ID = R.ROW_ID  AND 
       C.TBL_ID = t.ROW_ID         AND
       T.NAME LIKE 'CX%'           AND
       C.NAME NOT IN ('CONFLICT_ID', 
                      'CREATED', 
                      'CREATED_BY', 
                      'LAST_UPD', 
                      'LAST_UPD_BY', 
                      'MODIFICATION_NUM', 
                      'ROW_ID') 
      and R.NAME = 'Siebel Repository'
GROUP  BY R.NAME, 
          T.NAME 
ORDER  BY r.NAME, 
          t.NAME ;

PROMPT
PROMPT <P><P><h3>Dock Objects created for custom tables</h3>
COLUMN NAME_DOCK_OBJECT FORMAT A20 
COLUMN PRIMARY_TABLE    FORMAT A20 
COLUMN VISIBILITY_LEVEL FORMAT A20
COLUMN COMMENTS         FORMAT A60

SELECT D.NAME DOCK_OBJECT, 
       T.NAME PRIMARY_TABLE, 
       VISIBILITY_LEVEL, 
       COMMENTS  
FROM   &TABLE_OWNER..S_DOCK_OBJECT D, 
       &TABLE_OWNER..S_TABLE T 
WHERE  D.PR_TABLE_ID = T.ROW_ID     AND
       D.NAME NOT LIKE '%DockInit%' AND 
       D.NAME LIKE 'DX%' AND 
       D.INACTIVE_FLG = 'N' 
ORDER  BY D.NAME ;

PROMPT
PROMPT <P><P><h3>Audit trail configuration</h3>
COLUMN &TABLE_OWNER._REPOSITORY            FORMAT A25
COLUMN AUDIT_TRAIL_BUS_SVC_PROPERTY FORMAT A30
COLUMN VALUE                        FORMAT A25

SELECT R.NAME    &TABLE_OWNER._REPOSITORY,
       SUP.NAME  AUDIT_TRAIL_BUS_SVC_PROPERTY,
       SUP.VALUE VALUE
FROM   &TABLE_OWNER..S_SERVICE_UPROP SUP,
       &TABLE_OWNER..S_SERVICE SVC,
       &TABLE_OWNER..S_REPOSITORY R
WHERE  SVC.REPOSITORY_ID = R.ROW_ID    AND
       SUP.SERVICE_ID    = SVC.ROW_ID  AND 
       SVC.NAME          = 'Audit Trail Engine' and
	R.NAME = 'Siebel Repository'
ORDER  BY R.NAME ;

/* The following 2 sections were commented out due to long running time if there are large number of audited rows.

PROMPT <P><P><H3>Time range for transaction in database-based audit trail</H3>
COLUMN BUSCOMP_IN_DB_AUDITING  FORMAT A30
COLUMN CREATED_FROM            FORMAT A20
COLUMN CREATED_TO              FORMAT A20
column ENTRIES_IN_DB_AUDIT_TABLE for 999,999,999,999,999,999

SELECT BUSCOMP_NAME BUSCOMP_IN_DB_AUDITING,
       MIN(TO_CHAR(CREATED, 'DD-MON-YY HH:MI:SS')) CREATED_FROM,
       MAX(TO_CHAR(CREATED, 'DD-MON-YY HH:MI:SS')) CREATED_TO,
       COUNT(*) ENTRIES_IN_DB_AUDIT_TABLE
FROM   &TABLE_OWNER..S_AUDIT_ITEM
GROUP  BY BUSCOMP_NAME
ORDER  BY BUSCOMP_NAME ;


PROMPT <P><P><H3>Time range for transaction in file-based audit trail</H3>
COLUMN BUSCOMP_IN_FILE_AUDITING  FORMAT A30
COLUMN CREATED_FROM              FORMAT A20
COLUMN CREATED_TO                FORMAT A20

SELECT BUSCOMP_NAME BUSCOMP_IN_FILE_AUDITING,
       MIN(TO_CHAR(CREATED, 'DD-MON-YY HH:MI:SS')) CREATED_FROM,
       MAX(TO_CHAR(CREATED, 'DD-MON-YY HH:MI:SS')) CREATED_TO,
       COUNT(*) ENTRIES_IN_FILE_AUDIT_TRAIL
FROM   &TABLE_OWNER..S_AUDIT_TRAIL
GROUP  BY BUSCOMP_NAME
ORDER  BY BUSCOMP_NAME ;

*/

PROMPT
PROMPT <h2 id="Section12">Siebel Remote Information</h2>

PROMPT 
PROMPT <P><P><H3> Current Time </H3>

SELECT to_char (sysdate, 'MON-DD-YYYY HH24:MI:SS') "Current Time" from dual
/

PROMPT 
PROMPT <P><P><H3> Current Datebase </H3>

SELECT INSTANCE_NAME,
HOST_NAME,
VERSION,
STARTUP_TIME
from v$instance
/

PROMPT 
PROMPT <P><P><H3>Siebel Application System Preferences</H3>

SELECT SYS_PREF_CD "SYSTEM PREFERENCES", 
       VAL "VALUE"
FROM   &TABLE_OWNER..S_SYS_PREF 
WHERE  SYS_PREF_CD = 'Docking:Transaction Logging';


PROMPT 
PROMPT <P><P><H3>Mobile Client Information -summary</H3>

SELECT COUNT(*), NODE_TYPE_CD Type, nvl2(EFF_END_DT, 'End-dated', 'Active') Status 
FROM &TABLE_OWNER..S_NODE 
group by NODE_TYPE_CD, nvl2(EFF_END_DT, 'End-dated', 'Active');

PROMPT 
PROMPT <P><P><H3>Mobile Clients by Siebel Server</H3>

SELECT appserver "Siebel Server"
,      cnt       "Nbr of Active Mobile Clients"
,      decode (greatest(cnt, 0), least (cnt, 300), ''
,             'REDFLAG - More than 300 Mobile Clients on the Siebel Server. 
			    Verify hardware, nbr of Trxn Routers, etc.') "ES Warning"
  FROM (SELECT app_server_name appserver, count(*) cnt
          FROM &TABLE_OWNER..s_node
	   WHERE node_type_cd = 'REMOTE'
	     AND eff_end_dt   IS NULL
	     AND name <> 'HQ'
	   GROUP BY app_server_name)
order by appserver;

PROMPT 
PROMPT <P><P><H3>Mobile Client Information - detail</H3>
PROMPT comments: Two valid options for mobile users:
PROMPT 1) eff_end_date <> NULL and route_active_flg=N
PROMPT 2) eff_end_data IS NULL and route_active_flg=Y
col ROUTE_ACTIVE_FLG for a20
col EFF_END_DT for a15
break on APP_SERVER_NAME

SELECT APP_SERVER_NAME,NODE_TYPE_CD, ROUTE_ACTIVE_FLG, EFF_END_DT, NAME
FROM &TABLE_OWNER..S_NODE
WHERE  NODE_TYPE_CD = 'REMOTE'
ORDER BY 1,3,4,5;

PROMPT 
PROMPT <P><P><H3>S_Dock_Txn_Log Table</H3>
col "MinTXNID in log" for 999,999,999,999,999
col "MaxTXNID in log" for 999,999,999,999,999
col "Number of Transactions" for 999,999,999,999,999

SELECT MIN(TXN_ID) "MinTXNID in log",
       TO_CHAR(MIN(CREATED), 'DD-MON-YYYY HH24:MI:SS') "Oldest date",
       MAX(TXN_ID) "MaxTXNID in log",
       TO_CHAR(MAX(CREATED), 'DD-MON-YYYY HH24:MI:SS') "Newest date",
       COUNT(*) "Number of Transactions" 
  FROM &TABLE_OWNER..S_DOCK_TXN_LOG
;

PROMPT 
PROMPT <P><P><H3> Size of S_DOCK_TXN_LOG </H3>
col "size_MB" for 999,999,999

select 	segment_name, sum(bytes)/1024/1024 "size_MB"
from 	dba_segments
where 	owner = UPPER('&TABLE_OWNER') and
	segment_name = 'S_DOCK_TXN_LOG'
GROUP BY segment_name
;

PROMPT 
PROMPT <P><P><H3>S_DOCK_TXN_LOG table information by table and operation (count >= 10)</H3>
col count(*) for 999,999,999,999

select item_name, operation, count(*) 
from &TABLE_OWNER..s_dock_txn_log 
group by item_name, operation
having count(*) > 9
order by count(*) desc;

PROMPT 
PROMPT <P><P><H3>Transaction Processor Status - 'ROUTE'</H3>
col "Max dx file in Txnproc" for 999,999,999,999,999
col "Max txn id in file" for 999,999,999,999

select n.name, ds.type, ds.NODE_ID "Processor node id", n.EFF_END_DT "End-Dated", 
	ds.last_file_num "Max dx file in Txnproc", 
	ds.LAST_TXN_NUM  "Max txn id in file", 
	TO_CHAR(ds.LAST_UPD, 'DD-MON-YYYY HH24:MI:SS') LAST_UPD 
from &TABLE_OWNER..s_dock_status ds, &TABLE_OWNER..s_node n 
where ds.local_flg='Y' and ds.type='ROUTE' and 
ds.node_id = n.row_id and n.node_type_cd='TXNPROC'
order by 1;

PROMPT
PROMPT <P><P><H3>Transaction Processor Status - 'CLEAN'</H3>
col "Min dx file in Txnproc" for 999,999,999,999,999
col "Min txn id in file" for 999,999,999,999

select n.name, ds.type, ds.NODE_ID "Processor node id", n.EFF_END_DT "End-Dated", 
	ds.last_file_num + 1 "Min dx file in Txnproc", 
	ds.last_txn_num + 1 "Min txn id in file", 
	TO_CHAR(ds.LAST_UPD, 'DD-MON-YYYY HH24:MI:SS') LAST_UPD
from &TABLE_OWNER..s_dock_status ds, &TABLE_OWNER..s_node n 
where ds.local_flg='Y' and 
ds.type='CLEAN' and ds.node_id = n.row_id and n.node_type_cd='TXNPROC'
order by 1;

PROMPT 
PROMPT <P><P><H3>Transaction Processor Status</H3>
col LAST_FILE_NUM for 999,999,999,999
col LAST_TXN_NUM for 999,999,999,999
col TXNSTOPROCESS for 999,999,999,999

SELECT ST.ROW_ID, N.NAME, ST.TYPE, ST.LAST_FILE_NUM, ST.LAST_TXN_NUM, N.EFF_END_DT, 
TO_CHAR(ST.LAST_UPD, 'DD-MON-YYYY HH24:MI:SS') LAST_UPD, 
A.MAX_TXN_ID - ST.LAST_TXN_NUM TXNSTOPROCESS,
ST.ADDTL_INFO
FROM &TABLE_OWNER..S_DOCK_STATUS ST, &TABLE_OWNER..S_NODE N,
(SELECT MAX(TXN_ID) MAX_TXN_ID FROM &TABLE_OWNER..S_DOCK_TXN_LOG) A
WHERE ST.NODE_ID=N.ROW_ID
AND ST.LOCAL_FLG= 'Y'
AND ST.TYPE IN ('ROUTE', 'CLEAN')
AND N.NODE_TYPE_CD= 'TXNPROC'
AND (N.EFF_END_DT IS NULL OR N.EFF_END_DT > sysdate)
order by 2,3;

PROMPT 
PROMPT <P><P><H3>LowScanMark of TxnProc </H3>
COL "Low Scan Mark Value" FOR A50 
col "MinTXNID in log" for 999,999,999,999,999
col "MaxTXNID in log" for 999,999,999,999,999
col "Number of Transactions" for 999,999,999,999,999

select n.name, ds.NODE_ID "Processor node id", n.EFF_END_DT "End-Dated", substr(addtl_info, 1, 50) "Low Scan Mark Value" 
from &TABLE_OWNER..s_dock_status ds, &TABLE_OWNER..s_node n 
where ds.type='ROUTE' and ds.local_flg='Y' and ds.node_id = n.row_id and n.node_type_cd='TXNPROC'
order by 1;

PROMPT 
PROMPT <P><P><H3>Route STATUS: Status information for each active Siebel Remote node in regards to the existing content of S_DOCK_TXN_LOG</H3>
col TXNSTOROUTE for 999,999,999,999
break on APP_SERVER_NAME

SELECT N.APP_SERVER_NAME, N.NAME, N.row_id "Node_Id", LR.LAST_TXN_NUM, LAST_FILE_NUM,
A.MAX_TXN_ID - LR.LAST_TXN_NUM TXNSTOROUTE,
to_char(LR.LAST_UPD, 'DD-MON-YY HH24:MI:SS') "Last_Routed", N.ROUTE_ACTIVE_FLG
-- , LR.ADDTL_INFO -- to enable/un-comment only if needed!
from &TABLE_OWNER..S_NODE N, &TABLE_OWNER..S_DOCK_STATUS LR, 
(SELECT MAX(TXN_ID) MAX_TXN_ID FROM &TABLE_OWNER..S_DOCK_TXN_LOG) A
where nvl(n.eff_end_dt, sysdate) >= sysdate
AND LR.NODE_ID = N.ROW_ID AND LR.TYPE = 'ROUTE'
AND LR.LOCAL_FLG = 'Y' AND a.max_txn_id <> lr.last_txn_num 
AND N.ROUTE_ACTIVE_FLG = 'Y'
ORDER BY N.APP_SERVER_NAME,TXNSTOROUTE desc, N.NAME;

PROMPT 
PROMPT <P><P><H3>OUTBOX: Status information for each active user regarding contents of the OUTBOX</H3>
col "Max Txn" for 999,999,999
col "Min Txn" for 999,999,999
col "Max DX" for 999,999,999
col "Min DX" for 999,999,999
col "Max DX Sent" for 999,999,999,999
col "Max DX Applied" for 999,999,999,999


SELECT N.NAME, N.row_id "Node Id", YROUTE.LAST_TXN_NUM "Max Txn", NCLEAN.LAST_TXN_NUM+1 "Min Txn", 
  YROUTE.LAST_FILE_NUM "Max DX", NMERGE.LAST_FILE_NUM+1 "Min DX",
  NRECEIVE.LAST_FILE_NUM "Max DX Sent", NMERGE.LAST_FILE_NUM "Max DX Applied"
FROM &TABLE_OWNER..S_DOCK_STATUS YROUTE, 
	&TABLE_OWNER..S_DOCK_STATUS NRECEIVE, 
	&TABLE_OWNER..S_DOCK_STATUS NMERGE, 
  	&TABLE_OWNER..S_DOCK_STATUS NCLEAN, 
        &TABLE_OWNER..S_NODE N
WHERE 
  YROUTE.TYPE='ROUTE' AND YROUTE.LOCAL_FLG='Y' AND YROUTE.NODE_ID=NRECEIVE.NODE_ID AND
  NRECEIVE.TYPE='RECEIVE' AND NRECEIVE.LOCAL_FLG='N' AND NRECEIVE.NODE_ID=NCLEAN.NODE_ID AND
  NCLEAN.TYPE='CLEAN' AND NCLEAN.LOCAL_FLG='N' AND NCLEAN.NODE_ID=NMERGE.NODE_ID AND
  NMERGE.TYPE='MERGE' AND NMERGE.LOCAL_FLG='N' AND NMERGE.NODE_ID=N.ROW_ID
AND N.ROUTE_ACTIVE_FLG='Y'
AND nvl(N.EFF_END_DT, sysdate) >= sysdate 
ORDER BY NAME;

PROMPT 
PROMPT <P><P><H3>INBOX: Status information for each active user regarding contents of the INBOX</H3>
col "Max DX Received" for 9,999,999,999,999
col "Max DX Merged onto Server" for 9,999,999,999 heading "Max DX Merged|onto Server"

SELECT N.NAME, NROUTE.LAST_TXN_NUM "Max Txn", YCLEAN.LAST_TXN_NUM+1 "Min Txn", 
  NROUTE.LAST_FILE_NUM "Max DX", YMERGE.LAST_FILE_NUM+1 "Min DX",
  YRECEIVE.LAST_FILE_NUM "Max DX Received", YMERGE.LAST_FILE_NUM "Max DX Merged onto Server"
FROM &TABLE_OWNER..S_DOCK_STATUS NROUTE, 
	&TABLE_OWNER..S_DOCK_STATUS YRECEIVE, 
	&TABLE_OWNER..S_DOCK_STATUS YMERGE, 
  	&TABLE_OWNER..S_DOCK_STATUS YCLEAN, 
	&TABLE_OWNER..S_NODE N
WHERE 
NROUTE.TYPE='ROUTE' AND 
NROUTE.LOCAL_FLG='N' 
AND NROUTE.NODE_ID=YRECEIVE.NODE_ID 
AND   YRECEIVE.TYPE='RECEIVE' 
AND YRECEIVE.LOCAL_FLG='Y' 
AND YRECEIVE.NODE_ID=YCLEAN.NODE_ID 
AND   YCLEAN.TYPE='CLEAN' 
AND YCLEAN.LOCAL_FLG='Y' 
AND YCLEAN.NODE_ID=YMERGE.NODE_ID 
AND   YMERGE.TYPE='MERGE' 
AND YMERGE.LOCAL_FLG='Y' 
AND YMERGE.NODE_ID=N.ROW_ID
AND N.ROUTE_ACTIVE_FLG='Y'
AND nvl(N.EFF_END_DT, sysdate) >= sysdate 
ORDER BY NAME;

PROMPT
PROMPT <P><P><H3>Mobile Client Sync Time Range </H3>

SELECT 	 trunc(sds1.last_upd) "Last Syncd"
	,COUNT(*)
FROM 	 &Table_Owner..s_dock_Status sds1
	,&Table_Owner..s_dock_status sds2
	,&Table_Owner..s_node sn
WHERE 	 sds1.type = 'RECEIVE' and sds1.local_flg = 'N'
and   	 sds2.type = 'ROUTE' and sds2.local_flg = 'Y'
and 	 sn.row_id = sds1.node_id
and 	 sn.row_id = sds2.node_id
and 	 sn.eff_end_dt is null
group BY trunc(sds1.last_upd)
order by trunc(sds1.last_upd)
/

PROMPT
PROMPT <P><P><h3>Mobile Client Synchronization Gap</h3>
col name for a15
col "LstTxnNumRted" for 999,999,999,999
col "LstTxnNumRecvd" for 999,999,999,999
col "File Gap" for 999,999,999,999
col "Txn Gap" for 999,999,999,999


SELECT 	 sn.name
        ,sn.APP_SERVER_NAME
	,sds2.last_txn_num "LstTxnNumRted"
	,sds1.last_txn_num "LstTxnNumRecvd" 
	,(sds2.last_file_num - sds1.last_file_num) "File Gap"
	,(sds2.last_txn_num - sds1.last_txn_num) "Txn Gap"
	,to_char(sds1.last_upd,'mon-dd-yy hh24:mi:ss') "Last Syncd"
FROM 	 &Table_Owner..s_dock_Status sds1
	,&Table_Owner..s_dock_status sds2
	,&Table_Owner..s_node sn
WHERE 	 sds1.type = 'RECEIVE' and sds1.local_flg = 'N'
and   	 sds2.type = 'ROUTE' and sds2.local_flg = 'Y'
and 	 sn.row_id = sds1.node_id
and 	 sn.row_id = sds2.node_id
and 	 sn.eff_end_dt is null
and sn.NODE_TYPE_CD = 'REMOTE'
ORDER BY "Txn Gap" desc
/

PROMPT 
PROMPT <P><P><H3>Skip records</H3>

select count(*) from &TABLE_OWNER..s_dock_txn_skip
;

PROMPT 
PROMPT <P><P><h3>Skip records by server</h3>

select b.name server_name, count(*) 
from &TABLE_OWNER..s_dock_txn_skip a, &TABLE_OWNER..s_node b
where a.node_id = b.row_id
group by b.name
;

PROMPT 
PROMPT <P><P><H3>Skip records by hour</H3>

select to_char(created, 'YYYY-MM-DD HH24'), count(*)
from &TABLE_OWNER..s_dock_txn_skip
group by to_char(created, 'YYYY-MM-DD HH24')
order by to_char(created, 'YYYY-MM-DD HH24')
;

PROMPT 
PROMPT <P><P><H3>Orphan Transactions in S_DOCK_TXN_LOG</H3>

SELECT B.TXN_ID, B.ROW_ID, B.PAR_TXN_ID, B.OPERATION, B.ITEM_NAME
FROM &TABLE_OWNER..S_DOCK_TXN_LOG A, &TABLE_OWNER..S_DOCK_TXN_LOG B
WHERE A.ROW_ID(+) = B.PAR_TXN_ID 
AND A.ROW_ID IS NULL
ORDER BY B.TXN_ID;

PROMPT 
PROMPT <P><P><H3>number of rows in S_DOCK_TXN_SET</H3>

SELECT count(*)
FROM &TABLE_OWNER..S_DOCK_TXN_SET
;

PROMPT 
PROMPT <P><P><H3> rows of S_DOCK_TXN_SET without parent in Master Log</H3>
PROMPT

SELECT count(*) FROM &TABLE_OWNER..S_DOCK_TXN_SET SS
WHERE NOT EXISTS
(SELECT 'X' FROM &TABLE_OWNER..S_DOCK_TXN_LOG LG
WHERE LG.ROW_ID = SS.TXN_LOG_ID);

PROMPT
PROMPT <h2 id="Section13">Additional Information</h2>
PROMPT Information in this section is usually not required for PRR, but may be useful for looking at some issues.

PROMPT
PROMPT <P><P><h3>Oracle Hidden Parameters</h3>
COLUMN NAME FORMAT A39
COLUMN DESCRIPTION FORMAT A40
COLUMN VAL FORMAT A20
SELECT NAM.KSPPINM NAME, 
       NAM.KSPPDESC DESCRIPTION, 
       VAL.KSPPSTVL VALUE
  FROM X$KSPPI NAM, 
	 X$KSPPSV VAL 
 WHERE NAM.INDX = VAL.INDX 
and NAM.KSPPINM like '\_%' ESCAPE '\'
ORDER BY 1 ;

PROMPT
PROMPT <P><P><h3>Siebel Application System Preferences -- full list</h3>

SELECT SYS_PREF_CD "SYSTEM PREFERENCES", 
       VAL "VALUE"
FROM   &TABLE_OWNER..S_SYS_PREF 
ORDER  BY SYS_PREF_CD ;

PROMPT
PROMPT <h3>Stats on Key Siebel Object -- Tables</h3>
col tabname    format a20
col indname    format a18
col colname    format a15
col colexp     format a18
col conname    format a15
col srccond    format a30
col density    format 99,999.99999999
col num_rows   format 999,999,999,999
col blocks   format 999,999,999
col avg_row_len   format 9,999,999,999
col sample_size   format 999,999,999,999

select --+ rule
       table_name tabname, to_char(last_analyzed,'MM-DD-YYYY HH24:MI:SS') last_analyzed,
       num_rows, blocks, avg_row_len, sample_size
from all_tables 
where
OWNER = UPPER('&TABLE_OWNER') and
table_name in ('S_PARTY','S_CONTACT','S_ORG_EXT','S_EVT_ACT','S_SRV_REQ','S_OPTY','S_ORDER',
'S_POSTN_CON','S_ORG_BU','S_ORG_GROUP', 'S_CONTACT_FNXM', 'S_POSTN', 'S_CONTACT_FNX', 'S_SRV_REQ_BU', 'S_ACT_EMP', 'S_PARTY_RPT_REL')
order by table_name;

PROMPT
PROMPT <h3>Stats on Key Siebel Object -- Histograms</h3>
col num_distinct   format 999,999,999,999
col num_nulls   format 999,999,999,999

select --+ rule
       table_name tabname, column_name, to_char(last_analyzed,'MM-DD-YYYY HH24:MI:SS') last_analyzed, 
       num_distinct, num_nulls, density, num_buckets
from all_tab_columns
where
OWNER = UPPER('&TABLE_OWNER') and
table_name in ('S_PARTY','S_CONTACT','S_ORG_EXT','S_EVT_ACT','S_SRV_REQ','S_OPTY','S_ORDER',
'S_POSTN_CON','S_ORG_BU','S_ORG_GROUP', 'S_CONTACT_FNXM', 'S_POSTN', 'S_CONTACT_FNX', 'S_SRV_REQ_BU', 'S_ACT_EMP', 'S_PARTY_RPT_REL')
order by table_name, column_name ;

PROMPT
PROMPT <h3>Stats on Key Siebel Object -- Indexes</h3>

select --+ rule 
       a.table_name tabname, a.index_name indname, 
       to_char(last_analyzed,'MM-DD-YYYY HH24:MI:SS') last_analyzed,
       a.leaf_blocks lfblk, a.distinct_keys dkeys, 
       a.avg_leaf_blocks_per_key alvlblk, a.avg_data_blocks_per_key avgdblk, a.clustering_factor cf, a.blevel
from all_indexes a
where
OWNER = UPPER('&TABLE_OWNER') and
a.table_name in ('S_PARTY','S_CONTACT','S_ORG_EXT','S_EVT_ACT','S_SRV_REQ','S_OPTY','S_ORDER',
'S_POSTN_CON','S_ORG_BU','S_ORG_GROUP', 'S_CONTACT_FNXM', 'S_POSTN', 'S_CONTACT_FNX', 'S_SRV_REQ_BU', 'S_ACT_EMP', 'S_PARTY_RPT_REL')
order by a.table_name, a.index_name;

PROMPT
PROMPT <P><P><H3>Performance Statistics metrics/values from V$SYSSTAT table </H3>
COLUMN VALUE FORMAT 999,999,999,999,999,999

SELECT DECODE(CLASS,
   		 1, '(User)',
   		 2, '(Redo)',
   		 4, '(Enqueue)',
   		 8, '(Cache)',
   		 16, '(OS)',
   		 32, '(Real Application Clusters)',
   		 64, '(SQL)',
   		 128, '(Debug)'
       ) CLASS,
       NAME, 
       VALUE
FROM   V$SYSSTAT 
ORDER  BY CLASS ASC, NAME;

PROMPT
PROMPT <P><P><H3>System Events metrics/values from V$SYSTEM_EVENT table </H3>
COLUMN EVENT         FORMAT A32
COLUMN TOT_SECS_WAIT FORMAT 999,999,999,999,999,999
COLUMN AVG_WAIT_SECS FORMAT 999,999,999,999.99

SELECT EVENT, 
	 TOTAL_WAITS, 
	 TOTAL_TIMEOUTS, 
	 TIME_WAITED/100 TOT_SECS_WAIT, 
	 AVERAGE_WAIT/100 AVG_WAIT_SECS
FROM 	V$SYSTEM_EVENT
ORDER BY EVENT;

PROMPT
PROMPT <A href="#TopOfPage">Back to the Top of Report</A>
PROMPT </BODY>
PROMPT </HTML>
SET MARKUP HTML OFF ;
SPOOL OFF

exit
/

