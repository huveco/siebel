#!/usr/bin/ksh
########################################################
# Name:
# solaris_profile.ksh
#
# Description: 
# This script gathers Solaris/system information
#
# Created By:
# Oracle Advanced Customer Support Services
#
# Version : 10
#
# Update History:
#======================================================
#01/09/2002 (v1.0)
#------------------------------------------------------
# Created
#======================================================
#
#======================================================
#10/01/2002 (v1.1)
#------------------------------------------------------
# Added comments to each heading and removed redundant 
# commands/info
#======================================================
#02/03/2003 (v1.2)
#------------------------------------------------------
# Added section to collect network parameters (using ndd)
# that are recommended in Siebel Bookshelf -
# Appendix for Server Install Guide.
#======================================================
#04/04/2005 Scott Saunders (v1.3)
# Added section to get contents of /etc/system
# Added reads for siebel environment settings
# Added Actuate configuration file
# Added Resonate configuration file
# Removed redundant commands
#======================================================
#07/12/2006 Ely Kahwaty (v1.4)
# Added support for siebsvc ulimits check
# Added support for mpss (multiple page size support in 5.9)
# Added support for libumem check
# Added dump of server_start file
# Added addition vmstat call
# Added swap file info explanation
#======================================================
# 01/12/2009 Scott Saunders (v1.5)
# Added prtconf command
# Added prstat -s size command
#======================================================
# 08/11/2009 Scott Saunders (v1.6)
# Added 5 5 after prstat -s size command to control iterations
# Added prstat -s cpu 5 5 command
# Add uname -a to get patch info
# Add /usr/java/bin/java -fullversion to get java version
#======================================================
# 03/11/2010 Scott Saunders (v1.6)
# Added psrinfo -v for verbose processor details
# Added psrinfo -p to try to determine if processors are on same device
#======================================================
# 08/23/2011 Scott Saunders (v10)
# Added kstat commands for Solaris 10 for NIC settings
#======================================================
# 04/04/2012 Abdalla Abdelsalam (v11)
# Added Network Interfaces, Quota commands for Solaris 10 for NIC settings
########################################################

#------------------------------------------------------#
function header_line
#------------------------------------------------------#
{
 echo "#------------------------------------------------------#"
 echo "$*"
 echo "#------------------------------------------------------#\n"
} 
#------------------------------------------------------#


#------------------------------------------------------#
function footer_line
#------------------------------------------------------#
{
 echo "#------------------------------------------------------#\n\n"
} 
#------------------------------------------------------#


#------------------------------------------------------#
function get_hardware_configuration
#------------------------------------------------------#
{
  header_line "System Configuration"


  echo "================================"
  echo "/usr/platform/sun4u/sbin/prtdiag -v"
  echo "================================"
  /usr/platform/sun4u/sbin/prtdiag -v
  echo "================================\n\n"

  echo "================================"
  echo "/usr/platform/sun4u/sbin/psrinfo -v"
  echo "================================"
  /usr/platform/sun4u/sbin/psrinfo -v
  echo "================================\n\n"

  echo "================================"
  echo "/usr/platform/sun4u/sbin/psrinfo -p"
  echo "================================"
  /usr/platform/sun4u/sbin/psrinfo -p
  echo "================================\n\n"

  echo "========================================="
  echo "RAM/Memory (in MB): prtconf | grep Memory"
  echo "========================================="
  /usr/sbin/prtconf | grep Memory 
  echo "================================\n\n"


  echo "================================"
  echo "System Limits: ulimit -a"
  echo "================================"
  ulimit -a
  echo "================================\n\n"


  echo "================================"
  echo "Installed hardware: prtconf"
  echo "================================"
  /usr/sbin/prtconf
  echo "================================\n\n"

  echo "===================================="
  echo "Java version installed: -fullversion"
  echo "===================================="
  /usr/java/bin/java -fullversion
  echo "================================\n\n"

  echo "====================================="
  echo "Solaris patches installed: showrev -p"
  echo "====================================="
  showrev -p
  /usr/sbin/showrev -p
  echo "================================\n\n"


  echo "================================"
  echo "Siebsvc svstem Limits: plimit <pid>"
  echo "Should limit data and stack to avoid process bloating."
  echo "================================"
     PIDS=`/usr/bin/ps -ef | grep siebsvc | awk '{ print $2 }'`

     for pid in $PIDS
     do
        echo 'plimit process :' $pid
     plimit $pid
     done
   echo "================================\n\n"

  echo "================================"
  echo "Check if mpss and libumem are enabled for Solaris 9 SunOs 5.9 and above "
  echo "mpss is multiple page size support to improve performance "
  echo "libumem is page based memory allocator to improve performance "
  echo "================================"
     PIDS=`/usr/bin/ps -ef | grep siebmtshmw | awk '{ print $2 }'`

     for pid in $PIDS
     do
        echo 'pldd -p process :' $pid
     pldd $pid | grep libumem
     pldd $pid | grep mpss.so.1
     done
   echo "================================\n\n"


  echo "============================================="
  echo "Device Configuration Information: cfgadm -alv"
  echo "============================================="
  /usr/sbin/cfgadm -alv
  echo "================================\n\n"

  echo "======================================="
  echo "System/Console Messages:/usr/sbin/dmesg"
  echo "======================================="
  /usr/bin/dmesg
  echo "================================\n\n"
      
  footer_line
}
#------------------------------------------------------#


#------------------------------------------------------#
function get_storage_configuration
#------------------------------------------------------#
{
  header_line "Storage Configuration"
  
  echo "========================================================"
  echo "Currently Mounted Filesystems and Free/Used Space: df -k"
  echo "========================================================"
  /usr/bin/df -k
  echo "================================\n\n"
  
  echo "================================================"
  echo "Default Options for Filesystems: cat /etc/vfstab"
  echo "================================================"
  cat /etc/vfstab
  echo "================================\n\n"
  
  echo "================================================="
  echo "Mounted Filesystems with Options: cat /etc/mnttab"
  echo "================================================="
  cat /etc/mnttab
  echo "================================\n\n"

  echo "==================================================================="
  echo "Swap Space: swap -s and swap -l"
  echo "The output of the swap -s command shows the amount of swap space"
  echo "used and available, and further breaks down the used swap space"
  echo "into allocated and reserved. Allocated space represents swap space"
  echo "currently in use. Reserved space is in limbo, not available, not in"
  echo "use, but reserved for future use." 
    echo "=================================================================="
  echo "\nswap -s\n"
  /usr/sbin/swap -s
  echo ; echo 
  echo "\nswap -l\n"
  /usr/sbin/swap -l
  echo "================================\n\n"
  
  echo "================================"
  echo "Quota Information (repquota -va)"
  echo "================================"
  repquota -va
  echo "================================\n\n"
 
  footer_line

}
#------------------------------------------------------#


#------------------------------------------------------#
function get_network_configuration
#------------------------------------------------------#
{
  header_line "Network Configuration"


  echo "================================================"
  echo "Network Configuration - all tcp params: /usr/sbin/ndd /dev/tcp \? "
  echo "================================================"
  /usr/sbin/ndd /dev/tcp \?
  echo "================================\n\n"

  echo "================================================"
  echo "Network Configuration - kstat settings speed, duplex, autonegotiate "
  echo "================================================"
  kstat ce ce_device |egrep 'link_speed|link_status|link_duplex|cap_autoneg' 
  echo "================================\n\n"

  echo "================================================"
  echo "Network Configuration from Install Guide: /usr/sbin/ndd /dev/tcp tcp_conn_req_max_q"
  echo "================================================"
  /usr/sbin/ndd /dev/tcp tcp_conn_req_max_q
  echo "================================\n\n"

  echo "================================================"
  echo "Network Configuration from Install Guide: /usr/sbin/ndd /dev/tcp tcp_conn_req_max_q0"
  echo "================================================"
  /usr/sbin/ndd /dev/tcp tcp_conn_req_max_q0
  echo "================================\n\n"

  echo "================================================"
  echo "Network Configuration: /usr/sbin/ndd /dev/tcp tcp_max_buf"
  echo "================================================"
  /usr/sbin/ndd /dev/tcp tcp_max_buf
  echo "================================\n\n"

  echo "================================================"
  echo "Network Configuration: /usr/sbin/ndd /dev/tcp keepalive_interval"
  echo "================================================"
  /usr/sbin/ndd /dev/tcp keepalive_interval
  echo "================================\n\n"

  echo "================================================"
  echo "Network Interfaces: netstat -i and netstat -in"
  echo "================================================"
  echo "\n netstat -i\n"
  /usr/bin/netstat -i
  echo ; echo 
  echo "\n netstat -in\n"  
  /usr/bin/netstat -in
  echo "================================\n\n"

  echo "================================================"
  echo "Network Name Resolution: cat /etc/resolv.conf"
  echo "================================================"
  cat /etc/resolv.conf
  echo "================================\n\n"

  echo "================================"
  echo "Network Interfaces (netstat -in and ifconfig -a)"
  echo "================================"
  echo "\n netstat -i\n"
  netstat -i
  echo ; echo 
  echo "\n ifconfig -a\n"  
  ifconfig -a
  echo "================================\n\n"
  
  echo "================================================"
  echo "Network Routing Info: netstat -r and netstat -rn"
  echo "================================================"
  echo "\n netstat -r\n"
  /usr/bin/netstat -r
  echo ; echo 
  echo "\n netstat -rn\n"  
  netstat -rn  
  echo "================================\n\n"

  echo "================================"
  echo "Network Statistics: netstat -s"
  echo "================================"
  /usr/bin/netstat -s
  echo "================================\n\n"

  echo "======================================="
  echo "Current Network Connections: netstat -an"
  echo "======================================="
  /usr/bin/netstat -an
  echo "================================\n\n"
  
  echo "======================================="
  echo "ORACLE TNS Database Version indicator"
  echo "======================================="
  tnsping
  echo "================================\n\n"

  footer_line
}
#------------------------------------------------------#

#------------------------------------------------------#
function get_software_package_information
#------------------------------------------------------#
{
  header_line "Packages installed on this system"

  echo "====================================="
  echo "List of Packages Installed:pkginfo -x"
  echo "====================================="
  /usr/bin/pkginfo -x
  echo "====================================="

  echo "====================================="
  echo "List of Patches Installed:showrev -p"
  echo "====================================="
  /usr/bin/showrev -p
  echo "====================================="



  footer_line

}
#------------------------------------------------------#


#------------------------------------------------------#
function get_kernel_configuration
#------------------------------------------------------#
{
  header_line "Kernel Configuration"
  echo "=========================================="
  echo "Kernel Configuration File: cat /etc/system"
  echo "=========================================="
  /usr/bin/cat /etc/system
  echo "====================================="

  footer_line

}
#------------------------------------------------------#


#------------------------------------------------------#
function get_performance_information
#------------------------------------------------------#
{
  header_line "Performance Information (vmstat and ps)"



  echo "========================================="
  echo "Current Memory Usage Stats:vmstat -p 3 10"
  echo "========================================="
  /usr/bin/vmstat -p 3 10
  echo "================================\n\n"

  echo "================================================="
  echo "Cumulative CPU, Paging and Memory Stats:vmstat -s"
  echo "================================================="
  /usr/bin/vmstat -s
  echo "================================\n\n"
  
  echo "================================================="
  echo "Current CPU, Memory, I/O Stats:vmstat 5 10"
  echo "================================================="
  /usr/bin/vmstat 5 10
  echo "================================\n\n"


  echo "=================================="
  echo "Current Processes: /usr/ucb/ps aux"
  echo "=================================="
  /usr/ucb/ps aux
  echo "================================\n\n"

  echo "================================"
  echo "Current Processes: ps -ef"
  echo "================================"
  /usr/bin/ps -ef
  echo "================================\n\n"


  echo "==========================================="
  echo "Network and Streams Limits Info: netstat -m"
  echo "==========================================="
  /usr/bin/netstat -m
  echo "================================\n\n"
  
  echo "================================="
  echo "Disk I/O Information: iostat -xtc"
  echo "================================="
  /usr/bin/iostat -xtc 3 10
  echo "================================\n\n"
  
  echo "==========================================="
  echo "Connection memory footprint: prstat -s size"
  echo "==========================================="
  prstat -s size 5 5
  echo "================================\n\n"

  echo "==========================================="
  echo "Connection cpu footprint: prstat -s cpu    "
  echo "==========================================="
  prstat -s cpu 5 5
  echo "================================\n\n"



  footer_line

}
#------------------------------------------------------#

#------------------------------------------------------#
function get_resonate_information
#------------------------------------------------------#
{
  header_line "Resonate cdagentctl"
  echo "================================"
  echo "Resonate Contents of cdagentctl"
  echo "================================"
  more $RESONATE_ROOT/bin/cdagentctl
  echo "================================\n\n"


  footer_line
}
#------------------------------------------------------#

#------------------------------------------------------#
function get_siebel_env_settings
#------------------------------------------------------#
{
  header_line "Siebel environment settings"
  echo "================================"
  echo "Contents of siebenv.sh file"
  echo "================================"
  more $SIEBEL_ROOT/siebenv.sh
  echo "================================"
  echo "Contents of siebenv.csh file"
  echo "================================"
  more $SIEBEL_ROOT/siebenv.csh
  echo "================================"
  echo "Contents of start_server file"
  echo "================================"
  more $SIEBEL_ROOT/bin/start_server
  echo "================================"
  echo "Contents of siebmtshw file"
  echo "================================"
  more $SIEBEL_ROOT/bin/siebmtshw
  more $SIEBEL_ROOT/bin/siebmtshw.sh
  echo "================================\n\n"


  footer_line
}
#------------------------------------------------------#

#------------------------------------------------------#
function get_actuate_Settings
#------------------------------------------------------#
{
  header_line "Actuate Information"
  echo "================================"
  echo "Actuate Contents of rptsrvr.cfg"
  echo "================================"
  more $AC_SERVER_HOME/rptsrvr.cfg
  echo "================================"
  echo "Actuate Contents of start_srvr.sh"
  echo "================================"
  more $AC_SERVER_HOME/bin/start_srvr.cfg
  echo "================================"
  echo "Actuate Contents of server.xml  "
  echo "================================"
  more $CATALINA_HOME/conf/server.xml
  echo "================================\n\n"


  footer_line
}
#------------------------------------------------------#



#------------------------------------------------------#
function main
#------------------------------------------------------#
{
header_line "\t\tSolaris System Information"

if [ ! -z "$customer_name" ]
then
   echo "Customer Name : $customer_name\n\n"
fi

echo "********************************************************"
echo "Solaris Platform Profile Script ${profile_script_version}"
echo "Copyright Oracle Corporation"
echo "********************************************************"
echo "Customer Name     : $customer_name"
echo "Date              : `date`"
echo "Hostname          : `hostname`"
echo "Uptime            : `uptime`"
echo "User-id           : `id`"
echo "Env. Vars.        :\n`/usr/bin/env`\n"
echo "/usr/bin/uname -X : 'uname -X'"
echo "/usr/bin/uname -a : 'uname -a'"

  echo "====================================="
  echo "Basic Machine Information:showrev -a"
  echo "====================================="
  /usr/bin/showrev -a | /usr/bin/head -9
  echo "====================================="



footer_line

get_hardware_configuration
get_storage_configuration
get_network_configuration
get_performance_information
get_kernel_configuration
get_software_package_information
get_resonate_information
get_siebel_env_settings
get_actuate_Settings

}
#------------------------------------------------------#


#**********************************************************************#
profile_script_version="v1.6"

clear
echo "Please enter customer name : \c"
read customer_name
report_name="`hostname`_solaris_profile_${profile_script_version}_report_`date +%m-%d-%Y`.txt"
echo "The screen output will be spooled to $report_name"
echo "\n\nPress <ENTER> to continue ...\c"
read dummy_key

main | tee $report_name

echo "\n*******************************************************************"
echo "*******************************************************************\n"
echo "The screen output has been spooled to $report_name\n\n"
ls -l $report_name
echo "\n*******************************************************************"
echo "*******************************************************************\n"
echo "\n\n"
#**********************************************************************#
